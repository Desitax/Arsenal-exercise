﻿using AcademyProject.Data;
using AcademyProject.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademyProject.Core
{
    public class AcademyController
    {
        AcademyContext context;
        public AcademyController(AcademyContext context)
        {
            this.context = context;
        }

        public async Task AcademyConfigurations()
        {
            using var stream = new FileStream("../../../../AcademyProject.Data/Data/Academy.txt",
                FileMode.Open, FileAccess.Read);
            using var reader = new StreamReader(stream);

            if (context.Academies.Count() == 0)
            {
                while (reader.EndOfStream == false)
                {
                    var line = reader.ReadLine();
                    var parts = line.Split(',');

                    var academy = new Academy
                    {
                        Name = parts[0],
                        City = parts[1],
                        YearEstablished = int.Parse(parts[2])
                    };

                    await context.Academies.AddAsync(academy);
                    await context.SaveChangesAsync();
                }
            }
        }
        public async Task AddAcademy(string name, string city, int yearEstablished)
        {
            Academy academy = new Academy()
            { 
                Name=name,
                City=city,
                YearEstablished=yearEstablished
            };
            context.Academies.Add(academy);
            await context.SaveChangesAsync();
        }

        public async Task<List<Academy>> GetAllAcademies()
        {
            var academies = await context.Academies.ToListAsync();
            return academies;
        }

        public async Task UpdateAcademy(int id, string newName, string newCity, int newYearEstablished)
        {
            var academy = await context.Academies.FindAsync(id);
            if (academy != null)
            {
                academy.Name = newName;
                academy.City = newCity;
                academy.YearEstablished = newYearEstablished;
                await context.SaveChangesAsync();
            }
        }

        public async Task DeleteAcademy(int id)
        {
            var academy = await context.Academies.FindAsync(id);
            if (academy != null)
            {
                context.Academies.Remove(academy);
                await context.SaveChangesAsync();
            }
        }
        public async Task<Academy> GetAcademyByName(string academyName)
        {
            var list = await context.Academies
                .FirstOrDefaultAsync(a => a.Name == academyName);
            return list;

        }
        
    }
}

