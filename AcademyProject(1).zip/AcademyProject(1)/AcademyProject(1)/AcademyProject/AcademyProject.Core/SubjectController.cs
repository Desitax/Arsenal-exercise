﻿using AcademyProject.Data;
using AcademyProject.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademyProject.Core
{
    public class SubjectController
    {
        AcademyContext context;
        public SubjectController(AcademyContext context)
        {
            this.context = context;
        }


        public async Task SubjectConfigurations()
        {
            using var stream = new FileStream("../../../../AcademyProject.Data/Data/Subject.txt",
                FileMode.Open, FileAccess.Read);
            using var reader = new StreamReader(stream);

            if (context.Subjects.Count() == 0)
            {
                while (reader.EndOfStream == false)
                {
                    var line = reader.ReadLine();
                    var parts = line.Split(',');

                    var subject = new Subject
                    {
                        Name = parts[0],
                        Price = decimal.Parse(parts[1]),
                        Duration = int.Parse(parts[2]),
                    };

                    await context.Subjects.AddAsync(subject);
                    await context.SaveChangesAsync();
                }
            }
        }
        public async Task AddSubject(string name,decimal price,int duration)
        {
            Subject subject = new Subject()
            { 
                Name = name,
                Price = price,
                Duration = duration
            };

            context.Subjects.Add(subject);
            await context.SaveChangesAsync();
        }
        public async Task<List<Subject>> GetAllSubjects()
        {
            var subjects =await context.Subjects.ToListAsync();
            return subjects;
        }
        public async Task UpdateSubject(int id, string name, decimal price, int duration)
        {
            var subject =await context.Subjects.FindAsync(id);
            if (subject != null)
            {
                subject.Name = name;
                subject.Price =price;
                subject.Duration = duration;
                await context.SaveChangesAsync();
            }
        }
        public async Task DeleteSubject(int id)
        {
            var subject =await context.Subjects.FindAsync(id);
            if (subject != null)
            {
                context.Subjects.Remove(subject);
                await context.SaveChangesAsync();
            }
        }
        public async Task<List<Subject>> GetSubjectsByAcademyName(string academyName)
        {
            return await context.Courses
                .Where(c => c.Academy.Name.ToLower() == academyName.ToLower())
                .SelectMany(c => c.CourseSubjects.Select(cs => cs.Subject))
                .Distinct()
                .ToListAsync();
        }
        public async Task<Subject> GetSubjectInCourse(string courseName)
        {
            var subject = await context.Courses
                .Where(c => c.Name == courseName)
                .SelectMany(c => c.CourseSubjects)
                .Select(cs => cs.Subject)
                .Distinct()
                .FirstOrDefaultAsync();
            return subject;

        }
        public async Task<Course> GetCourseWithSubjects(string courseName)
        {
            var course = await context.Courses
                .Include(c => c.CourseSubjects)
                    .ThenInclude(cs => cs.Subject)
                .FirstOrDefaultAsync(c => c.Name == courseName);

            return course;
        }
    }
}
