﻿using AcademyProject.Data;
using AcademyProject.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademyProject.Core
{
    public class CourseSubjectController
    {
        AcademyContext context;
        public CourseSubjectController(AcademyContext context)
        {
            this.context = context;
        }

        public async Task CourseSubjectConfigurations()
        {
            using var stream = new FileStream("../../../../AcademyProject.Data/Data/CourseSubject.txt",
                FileMode.Open, FileAccess.Read);
            using var reader = new StreamReader(stream);

            if (context.CourseSubjects.Count() == 0)
            {
                while (reader.EndOfStream == false)
                {
                    var line = reader.ReadLine();
                    var parts = line.Split(',');

                    var courseSubject = new CourseSubject
                    {
                        CourseId = int.Parse(parts[0]),
                        SubjectId = int.Parse(parts[1])
                    };

                    await context.CourseSubjects.AddAsync(courseSubject);
                    await context.SaveChangesAsync();
                }
            }
        }
        public async Task AddCourseSubject(int courseId,int subjectId)
        {
            CourseSubject courseSubject = new CourseSubject()
            {
                CourseId = courseId,
                SubjectId = subjectId
            };
            context.CourseSubjects.Add(courseSubject);
            await context.SaveChangesAsync();
        }

        public async Task<List<CourseSubject>> GetAllCourseSubjects()
        {
            var courses = await context.CourseSubjects.ToListAsync();
            return courses;
        }

        public async Task UpdateCourseSubject(int courseId,int subjectId, int newCourseId, int newSubjectId)
        {
            var course = await context.CourseSubjects.FindAsync(courseId,subjectId);
            if (course != null)
            {
                course.CourseId = newCourseId;
                course.SubjectId = newSubjectId;
                await context.SaveChangesAsync();
            }
        }
        public async Task DeleteCourseSubject(int courseId, int subjectId)
        {
            var course = await context.CourseSubjects.FindAsync(courseId,subjectId);
            if (course != null)
            {
                context.CourseSubjects.Remove(course);
                await context.SaveChangesAsync();
            }
        }
        
    }

}
