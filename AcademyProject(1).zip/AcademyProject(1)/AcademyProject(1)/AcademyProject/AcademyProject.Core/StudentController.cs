﻿using AcademyProject.Data;
using AcademyProject.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademyProject.Core
{
    public class StudentController
    {
        AcademyContext context;
        public StudentController(AcademyContext context)
        {
            this.context = context;
        }

        public async Task StudentConfigurations()
        {
            using var stream = new FileStream("../../../../AcademyProject.Data/Data/Student.txt",
                FileMode.Open, FileAccess.Read);
            using var reader = new StreamReader(stream);

            if (context.Students.Count() == 0)
            {
                while (reader.EndOfStream == false)
                {
                    var line = reader.ReadLine();
                    var parts = line.Split(',');

                    var student = new Student
                    {
                        Name = parts[0],
                        Surname = parts[1],
                        Age = int.Parse(parts[2]),
                        City = parts[3],
                        DateOfBirth = DateTime.Parse(parts[4]),
                        AcademyId = int.Parse(parts[5])
                    };

                    await context.Students.AddAsync(student);
                    await context.SaveChangesAsync();
                }
            }
        }

        public async Task AddStudent(string name,string surname,int age,string city,DateTime dateOfBirth,int academyId)
        {
            Student student = new Student()
            {
                Name = name,
                Surname = surname,
                Age = age,
                City = city,
                DateOfBirth = dateOfBirth,
                AcademyId = academyId
            };
            context.Students.Add(student);
            await context.SaveChangesAsync();
        }
        public async Task<List<Student>> GetAllStudents()
        {
            var students= await context.Students.ToListAsync();
            return students;
        }
        public async Task UpdateStudent(int id, string name, string surname, int age, string city, DateTime dateOfBirth, int academyId)
        {
            var student=await context.Students.FindAsync(id);
            if(student != null)
            {
                student.Name = name;
                student.Surname = surname;
                student.Age =age;
                student.City = city;
                student.DateOfBirth = dateOfBirth;
                await context.SaveChangesAsync();
            }
        }
        public async Task DeleteStudent(int id)
        {
            var student= await context.Students.FindAsync(id);
            if(student != null)
            {
                context.Students.Remove(student);
                await context.SaveChangesAsync();
            }
        }
        public async Task<List<Student>> GetStudentsByCity(string city)
        {
            return await context.Students
                .Where(s => s.City == city)
                .ToListAsync();
        }
        public async Task<List<Student>> GetStudentsBySubject(string subjectName)
        {
            return await context.CourseSubjects
                .Where(cs => cs.Subject.Name == subjectName)
                .SelectMany(cs => cs.Course.Enrollments.Select(e => e.Student))
                .ToListAsync();
        }
    }
}
