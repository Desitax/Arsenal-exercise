﻿using AcademyProject.Data;
using AcademyProject.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademyProject.Core
{
    public class EnrollmentController
    {
        AcademyContext context;
        public EnrollmentController(AcademyContext context)
        {
            this.context = context;
        }


        public async Task EnrollmentConfigurations()
        {
            using var stream = new FileStream("../../../../AcademyProject.Data/Data/Enrollment.txt",
                FileMode.Open, FileAccess.Read);
            using var reader = new StreamReader(stream);

            if (context.Enrollments.Count() == 0)
            {
                while (reader.EndOfStream == false)
                {
                    var line = reader.ReadLine();
                    var parts = line.Split(',');

                    var enrollment = new Enrollment
                    {
                        StudentId = int.Parse(parts[0]),
                        CourseId = int.Parse(parts[1]),
                        DateEnrolled = DateTime.Parse(parts[2]),
                        Grade = int.Parse(parts[3]),
                    };

                    await context.Enrollments.AddAsync(enrollment);
                    await context.SaveChangesAsync();
                }
            }
        }
        public async Task AddEnrollment(int studentId,int courseId,DateTime dateEnrolled,double grade)
        {
            Enrollment enrollment = new Enrollment()
            { 
                StudentId = studentId,
                CourseId = courseId,
                DateEnrolled = dateEnrolled,
                Grade = grade
            };

            context.Enrollments.Add(enrollment);
            context.SaveChanges();
        }

        public async Task<List<Enrollment>> GetAllEnrollments()
        {
            var enrollments = await context.Enrollments.ToListAsync();
            return enrollments;
        }

        public async Task UpdateEnrollment(int studentId,int courseId, int newStudentId, int newCourseId,DateTime dateEnrolled,int grade)
        {
            var enrollments = await context.Enrollments.FindAsync(studentId,courseId);
            if (enrollments != null)
            {
                enrollments.StudentId =studentId;
                enrollments.CourseId = courseId;
                enrollments.DateEnrolled = dateEnrolled;
                enrollments.Grade = grade;
                await context.SaveChangesAsync();
            }
        }

        public async Task DeleteEnrollment(int id)
        {
            var enrollment = await context.Enrollments.FindAsync(id);
            if (enrollment != null)
            {
                context.Enrollments.Remove(enrollment);
                await context.SaveChangesAsync();
            }
        }

        public async Task<List<Student>> GetStudentsInCourse(string courseName)
        {
            var student = await context.Enrollments
                .Where(e => e.Course.Name.ToLower() == courseName.ToLower())
                .Select(e => e.Student)
                .ToListAsync();
            return student;
        }
    }
}
