﻿using AcademyProject.Data;
using AcademyProject.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademyProject.Core
{
    public class CourseController
    {
        AcademyContext context;
        public CourseController(AcademyContext context)
        {
            this.context = context;
        }


        public async Task CourseConfigurations()
        {
            using var stream = new FileStream("../../../../AcademyProject.Data/Data/Course.txt",
                FileMode.Open, FileAccess.Read);
            using var reader = new StreamReader(stream);

            if (context.Courses.Count() == 0)
            {
                while (reader.EndOfStream == false)
                {
                    var line = reader.ReadLine();
                    var parts = line.Split(',');

                    var course = new Course
                    {
                        Name = parts[0],
                        StartDate = DateTime.Parse(parts[1]),
                        EndDate = DateTime.Parse(parts[2]),
                        AcademyId = int.Parse(parts[3])
                    };

                    await context.Courses.AddAsync(course);
                    await context.SaveChangesAsync();
                }
            }
        }
        public async Task AddCourse(string name,DateTime startDate,DateTime endDate,int academyId)
        {
            Course course = new Course()
            {
                Name = name,
                StartDate = startDate,
                EndDate = endDate,
                AcademyId = academyId
            };

            context.Courses.Add(course);
            await context.SaveChangesAsync();
        }
        public async Task<List<Course>> GetAllCourses()
        {
            var courses = await context.Courses.ToListAsync();
            return courses;
        }
        public async Task UpdateCourse(int id, string name, DateTime startDate, DateTime endDate, int academyId)
        {
            var course = await context.Courses.FindAsync(id);
            if (course != null)
            {
                course.Name = name;
                course.StartDate = startDate;
                course.EndDate = endDate;
                await context.SaveChangesAsync();
            }
        }
        public async Task DeleteCourse(int id)
        {
            var course = await context.Courses.FindAsync(id);
            if (course != null)
            {
                context.Courses.Remove(course);
                await context.SaveChangesAsync();
            }
        }

        public async Task<List<Course>> GetCoursesByAcademy(string academyName)
        {
            var corses = await context.Courses
                .Where(c => c.Academy.Name == academyName)
                .ToListAsync();
            return corses;
        }
        public async Task<double> GetAverageGradeByCourseName(string courseName)
        {
            var entrollment = await context.Enrollments
                .Where(e => e.Course.Name == courseName)
                .Select(e => (double)e.Grade)
                .AverageAsync();
            return entrollment;
        }
        public async Task<List<Course>> GetCoursesWithStudentCount(int minStudents)
        {
             var courses = await context.Courses
                .Where(c => c.CourseSubjects
                .Select(cs => cs.Subject)
                .Count() >= minStudents)
                .ToListAsync();
            return courses;
        }
    }
}
