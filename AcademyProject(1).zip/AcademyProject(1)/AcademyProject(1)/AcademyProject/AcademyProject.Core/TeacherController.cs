﻿using AcademyProject.Data;
using AcademyProject.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademyProject.Core
{
    public class TeacherController
    {
        AcademyContext context;
        public TeacherController(AcademyContext context)
        {
            this.context = context;
        }


        public async Task TeacherConfigurations()
        {
            using var stream = new FileStream("../../../../AcademyProject.Data/Data/Teacher.txt",
                FileMode.Open, FileAccess.Read);
            using var reader = new StreamReader(stream);

            if (context.Teachers.Count() == 0)
            {
                while (reader.EndOfStream == false)
                {
                    var line = reader.ReadLine();
                    var parts = line.Split(',');

                    var teacher = new Teacher
                    {
                        Name = parts[0],
                        Surname = parts[1],
                        Age = int.Parse(parts[2]),
                        City = parts[3],
                        PhoneNumber = parts[4],
                        DateOfBirth = DateTime.Parse(parts[5]),
                        YearsOfTeaching = int.Parse(parts[6]),
                        AcademyId = int.Parse(parts[7]),
                        CourseId = int.Parse(parts[8])
                    };

                    await context.Teachers.AddAsync(teacher);
                    await context.SaveChangesAsync();
                }
            }
        }
        public async Task AddTeacher(string name, string surname, int age, string city, string phoneNumber, DateTime dateOfBirth, int yearsOfTeaching, int academyId, int courseId)
        {
            Teacher teacher = new Teacher()
            {
                Name = name,
                Surname = surname,
                Age = age,
                City = city,
                PhoneNumber = phoneNumber,
                DateOfBirth = dateOfBirth,
                YearsOfTeaching = yearsOfTeaching,
                AcademyId = academyId,
                CourseId = courseId
            };
            context.Teachers.Add(teacher);
            await context.SaveChangesAsync();
        }
        public async Task<List<Teacher>> GetAllTeachers()
        {
            var teacher =await context.Teachers.ToListAsync();
            return teacher;
        }
        public async Task UpdateTeacher(int id, string name, string surname, int age, string city, string phoneNumber, DateTime dateOfBirth, int yearsOfTeaching, int academyId, int courseId)
        {
            var teacher = await context.Teachers.FindAsync(id);
            if (teacher != null)
            {
                teacher.Name = name;
                teacher.Surname = surname;
                teacher.Age = age;
                teacher.City = city;
                teacher.PhoneNumber = phoneNumber;
                teacher.DateOfBirth = dateOfBirth;
                teacher.YearsOfTeaching=yearsOfTeaching;
                teacher.AcademyId = academyId;
                teacher.CourseId= courseId;
                context.SaveChangesAsync();
            }
        }
        public async Task DeleteTeacher(int id)
        {
            var teacher =await context.Teachers.FindAsync(id);
            if (teacher != null)
            {
                context.Teachers.Remove(teacher);
                await context.SaveChangesAsync();
            }
        }
        public async Task<List<Teacher>> GetTeachersWithExperience(int minYears)
        {
            return await context.Teachers
                .Where(t => t.YearsOfTeaching >= minYears)
                .ToListAsync();
        }
        public async Task<Teacher> GetTeacherInAcademyById(int academyId)
        {
            var academy= await context.Academies
                .Include(a => a.Teachers)
                 .FirstOrDefaultAsync(a => a.AcademyId == academyId);
            return academy.Teachers.FirstOrDefault();
        }
    }
}
