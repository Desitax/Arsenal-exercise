﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademyProject.Data.Models
{
    
    public class Subject
    {
        [Key]
        public int SubjectId { get; set; }
        [Required, MaxLength(50)]
        public string Name { get; set; }
        [Required]
        public decimal Price { get; set; }
        [Required]
        public int Duration { get; set; }

        public ICollection<CourseSubject> CourseSubjects { get; set; }
    }
}
