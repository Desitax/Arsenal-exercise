﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace AcademyProject.Data.Models
{
    public class Course
    {
        [Key]
        public int CourseId { get; set; }
        [Required, MaxLength(50)]
        public string Name { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
        [Required]
        public DateTime EndDate { get; set; }

        [ForeignKey(nameof(Academy))]
        public int? AcademyId { get; set; }
        public Academy Academy { get; set; }

        public ICollection<CourseSubject> CourseSubjects { get; set; }
        public ICollection<Enrollment> Enrollments { get; set; } 

    }
}
