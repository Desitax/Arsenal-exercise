﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademyProject.Data.Models
{
    public class Student
    {
        [Key]
        public int StudentId { get; set; }

        [Required, MaxLength(50)]
        public string Name { get; set; }

        [Required, MaxLength(50)]
        public string Surname { get; set; }

        [Required]
        public int Age { get; set; }
        [Required, MaxLength(50)]
        public string City { get; set; }

        [Required]
        public DateTime DateOfBirth { get; set; }

        [ForeignKey(nameof(Academy))]
        public int? AcademyId { get; set; }
        public Academy Academy { get; set; }

        public ICollection<Enrollment> Enrollments { get; set; } 
    }
}
