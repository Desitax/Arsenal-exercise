﻿using AcademyProject.Core;
using AcademyProject.Data;
using AcademyProject.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace AcademyProject.ConsoleApp.View
{
    public class Display
    {
        private AcademyController academyController;
        private CourseController courseController;
        private CourseSubjectController courseSubjectController;
        private EnrollmentController enrollmentController;
        private StudentController studentController;
        private SubjectController subjectController;
        private TeacherController teacherController;

        public Display(AcademyContext context)
        {
            this.academyController = new AcademyController(context);
            this.courseController = new CourseController(context);
            this.courseSubjectController = new CourseSubjectController(context);
            this.enrollmentController = new EnrollmentController(context);
            this.studentController = new StudentController(context);
            this.subjectController = new SubjectController(context);
            this.teacherController = new TeacherController(context);

        }

        public async Task Files()
        {
            await academyController.AcademyConfigurations();
            await courseController.CourseConfigurations();
            await studentController.StudentConfigurations();
            await subjectController.SubjectConfigurations();
            await teacherController.TeacherConfigurations();
            await courseSubjectController.CourseSubjectConfigurations();
            await enrollmentController.EnrollmentConfigurations();
        }

        public async Task StartUp()
        {
            Menu();
            string command = Console.ReadLine();
            while (true)
            {
                switch (command)
                {
                    case "1":
                        await GetAcademyByName();
                        break;
                    case "2":
                        await GetTeacherInAcademyById();
                        break;
                    case "3":
                        await GetCoursesByAcademy();
                        break;
                    case "4":
                        await GetSubjectInCourse();
                        break;
                    case "5":
                        await GetStudentsInCourse();
                        break;
                    case "6":
                        await GetStudentsByCity();
                        break;
                    case "7":
                        await GetTeachersWithExperience();
                        break;
                    case "8":
                        await GetCoursesWithStudentCount();
                        break;
                    case "9":
                        await GetAverageGradeByCourseName();
                        break;
                    case "10":

                        break;
                    case "11":
                        await AddAcademy();
                        break;
                    case "12":
                        await GetAllAcademies();
                        break;
                    case "13":
                        await UpdateAcademy();
                        break;
                    case "14":
                        await DeleteAcademy();
                        break;
                    case "15":
                        await AddCourse();
                        break;
                    case "16":
                        await GetAllCourses();
                        break;
                    case "17":
                        await UpdateCourse();
                        break;
                    case "18":
                        await DeleteCourse();
                        break;
                    case "19":
                        await AddCourseSubject();
                        break;
                    case "20":
                        await GetAllCourseSubjects();
                        break;
                    case "21":
                        await UpdateCourseSubject();
                        break;
                    case "22":
                        await DeleteCourseSubject();
                        break;
                    case "23":
                        await AddEnrollment();
                        break;
                    case "24":
                        await GetAllEnrollments();
                        break;
                    case "25":
                        await UpdateEnrollment();
                        break;
                    case "26":
                        await DeleteEnrollment();
                        break;
                    case "27":
                        await AddStudent();
                        break;
                    case "28":
                        await GetAllStudents();
                        break;
                    case "29":
                        await UpdateStudent();
                        break;
                    case "30":
                        await DeleteStudent();
                        break;
                    case "31":
                        await AddSubject();
                        break;
                    case "32":
                        await GetAllSubjects();
                        break;
                    case "33":
                        await UpdateSubject();
                        break;
                    case "34":
                        await DeleteSubject();
                        break;
                    case "35":
                        await AddTeacher();
                        break;
                    case "36":
                        await GetAllTeachers();
                        break;
                    case "37":
                        await UpdateTeacher();
                        break;
                    case "38":
                        await DeleteTeacher();
                        break;

                }
            }
        }
        public static void Menu()
        {
            Console.Clear();
            Console.WriteLine("Academy System Menu");
            Console.WriteLine("1. Get Academy by Name");
            Console.WriteLine("2. Get Teacher in Academy by ID");
            Console.WriteLine("3. Get Courses by Academy");
            Console.WriteLine("4. Get Subjects in Course");
            Console.WriteLine("5. Get Students in Course");
            Console.WriteLine("6. Get Students by City");
            Console.WriteLine("7. Get Teachers with Experience");
            Console.WriteLine("8. Get Courses with Student Count");
            Console.WriteLine("9. Get Average Grade by Course Name");

            Console.WriteLine("11. Add a new academy");
            Console.WriteLine("12. View all academies");
            Console.WriteLine("13. Update an academy");
            Console.WriteLine("14. Delete an academy");

            Console.WriteLine("15. Add a new course");
            Console.WriteLine("16. View all courses");
            Console.WriteLine("17. Update a course");
            Console.WriteLine("18. Delete a course");

            Console.WriteLine("19. Add a new courseSubject");
            Console.WriteLine("20. View all coursesSubjects");
            Console.WriteLine("21. Update a courseSubject");
            Console.WriteLine("22. Delete a courseSubject");

            Console.WriteLine("23. Add a new enrollment");
            Console.WriteLine("24. View all enrollments");
            Console.WriteLine("25. Update a enrollment");
            Console.WriteLine("26. Delete a enrollment");

            Console.WriteLine("27. Add a new student");
            Console.WriteLine("28. View all students");
            Console.WriteLine("29. Update a student");
            Console.WriteLine("30. Delete a student");

            Console.WriteLine("31. Add a new subject");
            Console.WriteLine("32. View all subjects");
            Console.WriteLine("33. Update a subject");
            Console.WriteLine("34. Delete a subject");

            Console.WriteLine("35. Add a new teacher");
            Console.WriteLine("36. View all teachers");
            Console.WriteLine("37. Update a teacher");
            Console.WriteLine("38. Delete a teacher");

            Console.WriteLine("39. Exit");
            Console.Write("Select an option: ");
        }
        public async Task GetAcademyByName()
        {
            Console.Write("Enter academy name:");
            string academyName = Console.ReadLine();
            var academy = await academyController.GetAcademyByName(academyName);
            if (academy != null)
            {
                Console.WriteLine($"{academy.Name} {academy.City}");
            }
            else
            {
                Console.WriteLine("Academy not found");
            }
        }
        public async Task GetTeacherInAcademyById()
        {
            Console.Write("Enter teacher ID:");
            int teacherId = int.Parse(Console.ReadLine());
            var teacher = await teacherController.GetTeacherInAcademyById(teacherId);
            if (teacher != null)
            {
                Console.WriteLine($"{teacher.Name} {teacher.Surname} {teacher.Age}");
            }
            else
            {
                Console.WriteLine("Teacher not found");
            }
        }
        public async Task GetCoursesByAcademy()
        {
            Console.Write("Enter academy name:");
            string academyName1 = Console.ReadLine();

            List<Course> courses = await courseController.GetCoursesByAcademy(academyName1);
            foreach (Course course in courses)
            {
                if (course != null)
                {
                    Console.WriteLine($"{course.Name}");
                }
                else
                {
                    Console.WriteLine("Course not found");
                }
            }
        }
        public async Task GetSubjectInCourse()
        {
            Console.Write("Enter course name: ");
            string courseName = Console.ReadLine();
            Subject subject = await subjectController.GetSubjectInCourse(courseName);
            if (subject != null)
            {
                Console.WriteLine(subject.Name);
            }
            else
            {
                Console.WriteLine("Subject not found");
            }
        }
        public async Task GetStudentsInCourse()
        {
            Console.Write("Enter course name");
            string courseName1 = Console.ReadLine();
            List<Student> students = await enrollmentController.GetStudentsInCourse(courseName1);
            foreach (var student in students)
            {
                if (students != null)
                {
                    Console.WriteLine($"{student.Name} {student.Surname}");
                }
                else
                {
                    Console.WriteLine("Student not found");
                }
            }
        }
        public async Task GetStudentsByCity()
        {
            Console.Write("Enter city:");
            string city = Console.ReadLine();
            List<Student> studentsCity = await studentController.GetStudentsByCity(city);
            foreach (var student in studentsCity)
            {
                if (studentsCity != null)
                {
                    Console.WriteLine($"{student.Name} {student.Surname}");
                }
                else
                {
                    Console.WriteLine("Student not found");
                }
            }
        }
        public async Task GetTeachersWithExperience()
        {
            Console.Write("Enter min year:");
            int minYear = int.Parse(Console.ReadLine());
            List<Teacher> teachers = await teacherController.GetTeachersWithExperience(minYear);
            foreach (var teacher1 in teachers)
            {
                if (teacher1 != null)
                {
                    Console.WriteLine(teacher1.Name);
                }
                else
                {
                    Console.WriteLine("Teacher not found");
                }
            }
        }
        public async Task GetCoursesWithStudentCount()
        {
            Console.Write("Enter min students:");
            int minStudents = int.Parse(Console.ReadLine());
            List<Course> courses1 = await courseController.GetCoursesWithStudentCount(minStudents);
            foreach (var course1 in courses1)
            {
                if (course1 != null)
                {
                    Console.WriteLine(course1.Name);
                }
                else
                {
                    Console.WriteLine("Course not found");
                }

            }
        }
        public async Task GetAverageGradeByCourseName()
        {
            Console.Write("Enter course name:");
            string courseName2 = Console.ReadLine();
            double grade = await courseController.GetAverageGradeByCourseName(courseName2);
            Console.WriteLine(grade);
        }
        public async Task AddAcademy()
        {
            Console.Write("Enter academy name:");
            string academyName = Console.ReadLine();
            Console.Write("Enter academy city:");
            string academyCity = Console.ReadLine();
            Console.Write("Enter academy year established:");
            int yearEstablished = int.Parse(Console.ReadLine());
            await academyController.AddAcademy(academyName, academyCity, yearEstablished);
            Console.WriteLine("Academy was added");
        }
        public async Task GetAllAcademies()
        {
            List<Academy> academies = await academyController.GetAllAcademies();
            foreach(var academy in academies)
            {
                Console.WriteLine($"Academy {academy.Name} located in {academy.City}. Established in {academy.YearEstablished}");
            }
        }
        public async Task UpdateAcademy()
        {
            Console.Write("Enter academy id: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Enter academy new name: ");
            string newName = Console.ReadLine();

            Console.Write("Enter new city: ");
            string newCity = Console.ReadLine();

            Console.Write("Enter new established year: ");
            int newYearEstablished = int.Parse(Console.ReadLine());

            await academyController.UpdateAcademy(id, newName, newCity, newYearEstablished);
        }
        public async Task DeleteAcademy()
        {
            Console.Write("Enter academy id: ");
            int id = int.Parse(Console.ReadLine());
            await academyController.DeleteAcademy(id);
        }
        public async Task AddCourse()
        {
            Console.Write("Enter course name: ");
            string name= Console.ReadLine();
            Console.Write("Enter start date: ");
            DateTime startDate= DateTime.Parse(Console.ReadLine());
            Console.Write("Enter end date: ");
            DateTime endDate = DateTime.Parse(Console.ReadLine());
            Console.Write("Enter academy ID:");
            int academyId= int.Parse(Console.ReadLine());
            await courseController.AddCourse(name, startDate, endDate,academyId);
            Console.WriteLine("Course was added!");
        }
        public async Task GetAllCourses()
        {
            List<Course> courses = await courseController.GetAllCourses();
            foreach (var course in courses)
            {
                Console.WriteLine($"Course {course.Name}, {course.StartDate}, {course.EndDate}");
            }
        }
        public async Task UpdateCourse()
        {
            Console.Write("Enter Course id: ");
            int id = int.Parse(Console.ReadLine());
            Console.Write("Enter course name: ");
            string name=Console.ReadLine();
            Console.Write("Enter course start date: ");
            DateTime startDate=DateTime.Parse(Console.ReadLine());
            Console.Write("Enter course end date: ");
            DateTime endDate = DateTime.Parse(Console.ReadLine());
            Console.Write("Enter academy ID: ");
            int academyId = int.Parse(Console.ReadLine());
            await courseController.UpdateCourse(id, name, startDate, endDate, academyId);
        }
        public async Task DeleteCourse()
        {
            Console.Write("Enter course id: ");
            int id = int.Parse(Console.ReadLine());
            await courseController.DeleteCourse(id);
        }
        public async Task AddCourseSubject()
        {
            Console.Write("Enter course id: ");
            int courseId=int.Parse(Console.ReadLine()); 

            Console.Write("Enter subject ID:");
            int subjectId = int.Parse(Console.ReadLine());

            await courseSubjectController.AddCourseSubject(courseId,subjectId);
            Console.WriteLine("CourseSubject was added!");
        }
        public async Task GetAllCourseSubjects()
        {
            List<CourseSubject> courses = await courseSubjectController.GetAllCourseSubjects();
            foreach (var item in courses)
            {
                Console.WriteLine($"CourseId {item.CourseId}, SubjectId {item.SubjectId}");
            }
        }
        public async Task UpdateCourseSubject()
        {
            Console.Write("Enter course ID: ");
            int courseId = int.Parse(Console.ReadLine());

            Console.Write("Enter subject ID: ");
            int subjectId = int.Parse(Console.ReadLine());

            Console.Write("Enter new course ID: ");
            int newCourseId = int.Parse(Console.ReadLine());

            Console.Write("Enter new subject ID: ");
            int newSubjectId = int.Parse(Console.ReadLine());

            await courseSubjectController.UpdateCourseSubject(courseId,subjectId,newCourseId,newSubjectId);
        }
        public async Task DeleteCourseSubject()
        {
            Console.Write("Enter course ID: ");
            int courseId = int.Parse(Console.ReadLine());

            Console.Write("Enter subject ID: ");
            int subjectId = int.Parse(Console.ReadLine());

            await courseSubjectController.DeleteCourseSubject(courseId,subjectId);
        }
        public async Task AddEnrollment()
        {
            Console.Write("Enter student ID: ");
            int studentID = int.Parse(Console.ReadLine());

            Console.Write("Enter course ID:");
            int courseID = int.Parse(Console.ReadLine());

            Console.Write("Enter date enrolled: ");
            DateTime date = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter enrollment grade:");
            int grade = int.Parse(Console.ReadLine());

            await enrollmentController.AddEnrollment(studentID, courseID,date,grade);
            Console.WriteLine("Enrollment was added!");
        }
        public async Task GetAllEnrollments()
        {
            List<Enrollment> enrollment = await enrollmentController.GetAllEnrollments();
            foreach (var item in enrollment)
            {
                Console.WriteLine($"StudentId {item.StudentId}, CourseId {item.CourseId}, dateEnrolled {item.DateEnrolled}, grade {item.Grade}");
            }
        }
        public async Task UpdateEnrollment()
        {
            Console.Write("Enter course ID: ");
            int courseId = int.Parse(Console.ReadLine());

            Console.Write("Enter subject ID: ");
            int subjectId = int.Parse(Console.ReadLine());

            Console.Write("Enter new course ID: ");
            int newCourseId = int.Parse(Console.ReadLine());

            Console.Write("Enter new subject ID: ");
            int newSubjectId = int.Parse(Console.ReadLine());

            await courseSubjectController.UpdateCourseSubject(courseId, subjectId, newCourseId, newSubjectId);
        }
        public async Task DeleteEnrollment()
        {
            Console.Write("Enter student ID: ");
            int studentId = int.Parse(Console.ReadLine());

            Console.Write("Enter course ID: ");
            int courseId = int.Parse(Console.ReadLine());

            await courseSubjectController.DeleteCourseSubject(studentId, courseId);
        }
        public async Task AddStudent()
        {
            Console.Write("Enter student name: ");
            string name = Console.ReadLine();

            Console.Write("Enter student surname: ");
            string surname = Console.ReadLine();

            Console.Write("Enter student age:");
            int age = int.Parse(Console.ReadLine());

            Console.Write("Enter student city: ");
            string city = Console.ReadLine();

            Console.Write("Enter student date of birth: ");
            DateTime date = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter academy ID: ");
            int id = int.Parse(Console.ReadLine());

            await studentController.AddStudent(name,surname,age,city,date,id);
            Console.WriteLine("Enrollment was added!");
        }
        public async Task GetAllStudents()
        {
            List<Student> students = await studentController.GetAllStudents();
            foreach (var item in students)
            {
                Console.WriteLine($"Student name {item.Name}, surname {item.Surname}, age {item.Age}, city {item.City}, date of birth {item.DateOfBirth}, academy ID {item.AcademyId}");
            }
        }
        public async Task UpdateStudent()
        {
            Console.Write("Enter student ID: ");
            int studentId = int.Parse(Console.ReadLine());

            Console.Write("Enter student name: ");
            string name = Console.ReadLine();

            Console.Write("Enter student surname: ");
            string surname = Console.ReadLine();

            Console.Write("Enter student age:");
            int age = int.Parse(Console.ReadLine());

            Console.Write("Enter student city: ");
            string city = Console.ReadLine();

            Console.Write("Enter date of birth: ");
            DateTime date = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter academy ID: ");
            int id = int.Parse(Console.ReadLine());

            await studentController.UpdateStudent(studentId,name,surname,age,city,date,id);
        }
        public async Task DeleteStudent()
        {
            Console.Write("Enter student ID: ");
            int studentId = int.Parse(Console.ReadLine());

            await studentController.DeleteStudent(studentId);
        }
        public async Task AddSubject()
        {
            Console.Write("Enter subject name: ");
            string name = Console.ReadLine();

            Console.Write("Enter subject price: ");
            decimal price=decimal.Parse(Console.ReadLine());

            Console.Write("Enter subject duration:");
            int duration = int.Parse(Console.ReadLine());

            await subjectController.AddSubject(name,price,duration);
            Console.WriteLine("Subject was added!");
        }
        public async Task GetAllSubjects()
        {
            List<Subject> subjects = await subjectController.GetAllSubjects();
            foreach (var item in subjects)
            {
                Console.WriteLine($"Subject name {item.Name}, price {item.Price}, duration {item.Duration}");
            }
        }
        public async Task UpdateSubject()
        {
            Console.Write("Enter student ID: ");
            int studentId = int.Parse(Console.ReadLine());

            Console.Write("Enter subject name: ");
            string name = Console.ReadLine();

            Console.Write("Enter subject price: ");
            decimal price = decimal.Parse(Console.ReadLine());

            Console.Write("Enter subject duration:");
            int duration = int.Parse(Console.ReadLine());

            await subjectController.UpdateSubject(studentId, name,price,duration);
        }
        public async Task DeleteSubject()
        {
            Console.Write("Enter subject ID: ");
            int subjectId = int.Parse(Console.ReadLine());

            await subjectController.DeleteSubject(subjectId);
        }
        public async Task AddTeacher()
        {
            Console.Write("Enter teacher name: ");
            string name = Console.ReadLine();

            Console.Write("Enter teacher surname: ");
            string surname = Console.ReadLine();

            Console.Write("Enter teacher age:");
            int age = int.Parse(Console.ReadLine());

            Console.Write("Enter teacher city: ");
            string city = Console.ReadLine();

            Console.Write("Enter teacher phoneNumber: ");
            string phoneNumber = Console.ReadLine();

            Console.Write("Enter teacher date of birth: ");
            DateTime date = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter teacher years of teaching: ");
            int yearsOfTeaching = int.Parse(Console.ReadLine());

            Console.Write("Enter academy ID:");
            int academyId = int.Parse(Console.ReadLine());

            Console.Write("Enter course ID: ");
            int courseId = int.Parse(Console.ReadLine());

            await teacherController.AddTeacher(name, surname, age, city,phoneNumber, date, yearsOfTeaching,academyId,courseId);
            Console.WriteLine("Teacher was added!");
        }
        public async Task GetAllTeachers()
        {
            List<Teacher> teachers = await teacherController.GetAllTeachers();
            foreach (var item in teachers)
            {
                Console.WriteLine($"Teacher name {item.Name}, surname {item.Surname}, age {item.Age}, city {item.City},phone number {item.PhoneNumber}, date of birth {item.DateOfBirth},years of Teaching {item.YearsOfTeaching}, academy ID {item.AcademyId}, course ID {item.CourseId}");
            }
        }
        public async Task UpdateTeacher()
        {
            Console.Write("Enter teacher ID: ");
            int teacherId = int.Parse(Console.ReadLine());

            Console.Write("Enter teacher name: ");
            string name = Console.ReadLine();

            Console.Write("Enter teacher surname: ");
            string surname = Console.ReadLine();

            Console.Write("Enter teacher age:");
            int age = int.Parse(Console.ReadLine());

            Console.Write("Enter teacher city: ");
            string city = Console.ReadLine();

            Console.Write("Enter teacher phoneNumber: ");
            string phoneNumber = Console.ReadLine();

            Console.Write("Enter teacher date of birth: ");
            DateTime date = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter teacher years of teaching: ");
            int yearsOfTeaching = int.Parse(Console.ReadLine());

            Console.Write("Enter academy ID:");
            int academyId = int.Parse(Console.ReadLine());

            Console.Write("Enter course ID: ");
            int courseId = int.Parse(Console.ReadLine());

            await teacherController.UpdateTeacher(teacherId, name, surname, age, city, phoneNumber, date, yearsOfTeaching, academyId, courseId);
        }
        public async Task DeleteTeacher()
        {
            Console.Write("Enter teacher ID: ");
            int teacherId = int.Parse(Console.ReadLine());

            await teacherController.DeleteTeacher(teacherId);
        }
    }
}
