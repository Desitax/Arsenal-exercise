﻿// See https://aka.ms/new-console-template for more information

using AcademyProject.ConsoleApp.View;
using AcademyProject.Data;
using System;

namespace AcademyProject.ConsoleApp
{
    public class Program
    {
        static async Task Main(string[] args)
        {
            AcademyContext context = new AcademyContext();
            Display display = new Display(context);
            await display.Files();
            //display.StartUp();
        }
    }
}