﻿using HotelManager.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManager.Controller
{
    public class HotelManagerController
    {
        public HotelManagerContext context=new HotelManagerContext();

        public List<string> ReturnGuestsNames()
        {
            var Guests=context.Guests
                .Select(x => new
            {
                    FirstName = x.FirstName,
                    LastName = x.LastName,
            }).ToList();

            List<string> names = new List<string>();
            foreach (var guests in Guests)
            {
                names.Add($"{guests.FirstName}, {guests.LastName}");
            }
            return names;
        }
        public void AddGuest(string FirstName,string LastName,string Ucn,string phoneNumber)
        {
            Guest guest = new Guest()
            {
                FirstName=FirstName,
                LastName=LastName,
                Ucn=Ucn,
                PhoneNumber=phoneNumber
            };
            context.Guests.Add(guest);
            context.SaveChanges();
            Console.WriteLine("The guest is added sucessfully");
        }
        public List<int> ReturnRoomsNumbers()
        {
            var Rooms = context.Rooms
                .Select(x => new
                {
                    Number = x.Number,
                    Price = x.Price,
                }).Where(x=>x.Price>=80 && x.Price<=100).OrderByDescending(x=>x.Price).ToList();
            List<int> numbers=new List<int>();
            foreach (var item in Rooms)
            {
                numbers.Add(item.Number);
            }
            return numbers;
        }
        public void DeleteReservation(int id)
        {
            Reservation reservation=context.Reservations.FirstOrDefault(x=>x.Id==id);
            if (reservation!=null)
            {
                context.Reservations.Remove(reservation);
                Console.WriteLine("Reservation is deleted");
            }
        }
        public int ReturnCountOfFreeRooms()
        {
            var Rooms = context.Rooms
                .Select(x => new
                {
                    Status = x.Status,
                }).Where(x=>x.Status=="free").ToList();
            return Rooms.Count();
        }
        public decimal ReturnMinimalPrice(string status)
        {
            var room = context.Rooms
                .Select(x => new
                {
                    Status = x.Status,
                    Price = x.Price,
                }).Where(x => x.Status == status).OrderBy(o=>o.Price).ToList();
            return room.First().Price;
        }
        public List<int> ReturnNotCompletedReservations()
        {
            var reservation = context.Reservations
                .Select(x => new
                {
                    ReleaseDate= x.ReleaseDate,
                    Id = x.Id
                }).Where(r => r.ReleaseDate > DateOnly.FromDateTime(DateTime.Now)).Select(s=>s.Id)
                        .ToList();
            return reservation.ToList();
        }
    }

}
