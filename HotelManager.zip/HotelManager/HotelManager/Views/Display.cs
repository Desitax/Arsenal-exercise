﻿using HotelManager.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManager.Views
{
    public class Display
    {
        public HotelManagerController controller =new HotelManagerController();
        public void ShowMenu()
        {
            Menu();
            string command = Console.ReadLine();
            while (command != "End")
            {
                switch (command)
                {
                    case "1":
                        List<string> names = controller.ReturnGuestsNames();
                        foreach (var item in names)
                        {
                            Console.WriteLine(item);
                        }
                        break;

                    case "2":
                        Console.WriteLine("Enter guest first name: ");
                        string name = Console.ReadLine();

                        Console.WriteLine("Enter guest second name: ");
                        string secondName = Console.ReadLine();

                        Console.WriteLine("Enter guest ucn: ");
                        string ucn = Console.ReadLine();

                        Console.WriteLine("Enter guest phone number: ");
                        string number = Console.ReadLine();

                        controller.AddGuest(name, secondName, ucn, number);
                        break;
                    case "3":
                        List<int> numbers = controller.ReturnRoomsNumbers();
                        foreach (var item in numbers)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                    case "4":
                        Console.WriteLine("Enter reservation id: ");
                        int id = int.Parse(Console.ReadLine());

                        controller.DeleteReservation(id);
                        break;
                    case "5":
                        int result = controller.ReturnCountOfFreeRooms();
                        Console.WriteLine(result);
                        break;
                    case "6":
                        Console.WriteLine("Enter room status: ");
                        string status = Console.ReadLine();

                        decimal result1 = controller.ReturnMinimalPrice(status);
                        Console.WriteLine(result1);
                        break;
                    case "7":
                        List<int> notCompleted = controller.ReturnNotCompletedReservations();
                        foreach (var item in notCompleted)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                }
                command = Console.ReadLine();
            }
        }

        public void Menu()
        {
            Console.WriteLine("Menu:");
            Console.WriteLine("1. Show all guests");
            Console.WriteLine("2. Add new guest");
            Console.WriteLine("3. Rooms with price between 80 and 100 BGN (descending order)");
            Console.WriteLine("4. Delete reservation by ID");
            Console.WriteLine("5. Count of free rooms");
            Console.WriteLine("6. Minimum room price by status");
            Console.WriteLine("7. IDs of active reservations");
            Console.Write("Please enter your choice: ");
        }
    }
}
