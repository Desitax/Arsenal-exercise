﻿using System.Data;
using System.Threading.Channels;

namespace Library
{
    internal class Program
    {
        static void Main(string[] args)
        {
           List<Book> books = new List<Book>(); 
           List<Reader>readers = new List<Reader>();
           List<Borrowing> borrowings = new List<Borrowing>();
           ShowMenu();
           int command=int.Parse(Console.ReadLine());

           while(command!=0)
           {
                switch(command)
                {
                    case 1:
                        Console.WriteLine("Enter book title: ");
                        string title=Console.ReadLine();

                        Console.WriteLine("Enter book author: ");
                        string author=Console.ReadLine();

                        Console.WriteLine("Enter book genre: ");
                        string genre=Console.ReadLine();

                        Console.WriteLine("Enter book count of copies: ");
                        int countOfCopies=int.Parse(Console.ReadLine());

                        Console.WriteLine("Enter book count of borrowing: ");
                        int countOfBorrowing=int.Parse(Console.ReadLine());

                        Book book=new Book(title,author,genre,countOfCopies,countOfBorrowing);
                        books.Add(book);
                        break;
                    case 2:
                        Console.WriteLine("Enter reader name: ");
                        string name = Console.ReadLine();

                        Console.WriteLine("Enter reader id: ");
                        int id=int.Parse(Console.ReadLine());

                        Console.WriteLine("Enter reader age: ");
                        int age = int.Parse(Console.ReadLine());

                        Reader reader=new Reader(name,id,age);
                        readers.Add(reader);
                        break;
                    case 3:
                        Console.WriteLine("Enter reader name: ");
                        string nameReader=Console.ReadLine();
                        Reader reader1=readers.FirstOrDefault(r=>r.Name==nameReader);

                        Console.WriteLine("Enter book title: ");
                        string bookTitle=Console.ReadLine();
                        Book book1=books.FirstOrDefault(r=>r.Title==bookTitle);

                        DateTime dateOfBorrowing= DateTime.Now;

                        DateTime dateOfReturn= DateTime.Now.AddDays(30);

                        Borrowing borrowing = new Borrowing(reader1, book1, dateOfBorrowing, dateOfReturn);
                        borrowings.Add(borrowing);
                        reader1.Books.Add(book1);
                        borrowing.Book.CountCopy--;
                        borrowing.Book.CountBorrowed++;
                      
                        break;
                    case 4:
                        books.ForEach(b => Console.WriteLine(b.ToString()));
                            break;
                    case 5:
                        readers.ForEach(r => Console.WriteLine(r.ToString()));
                        break;
                    case 6:
                        Console.WriteLine("Enter reader name:");
                        string nameOfReader=Console.ReadLine();

                        Reader reader2=readers.FirstOrDefault(r=>r.Name==nameOfReader);
                        foreach (var item in reader2.Books)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                    case 7:
                        List<Reader> readersNew = readers.Where(r => r.Books.Count > 0).ToList();
                        foreach (var item in readersNew)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                    case 8:
                        List<Book> booksNew=books.Where(b=>b.CountCopy>b.CountBorrowed).ToList();
                        foreach (var item in booksNew)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                    case 9:
                        List<Borrowing> lateReturnedBooks = borrowings.Where(b => b.DateOfReturn<b.DateOfBorrowing).ToList();
                        foreach (var item in lateReturnedBooks)
                        {
                            Console.WriteLine(item.ToString());
                        }
                        break;
                    case 10:

                        Book mostBorrowed=books.OrderByDescending(b=>b.CountBorrowed).FirstOrDefault();
                        Console.WriteLine(mostBorrowed);
                        break;

                }
                command = int.Parse(Console.ReadLine());
           }
        }
        static void ShowMenu()
        {
            Console.WriteLine("Choose number to execute: ");
            Console.WriteLine("0.Exit app!");
            Console.WriteLine("1.Enter info about books: ");
            Console.WriteLine("2.Enter info about readers: ");
            Console.WriteLine("3.Enter info about borrow: ");
            Console.WriteLine("4.Show all books in library:");
            Console.WriteLine("5.Show all readers in library: ");
            Console.WriteLine("6.Show books borrowed by a certain reader: ");
            Console.WriteLine("7.Show readers with active borrows: ");
            Console.WriteLine("8.Show all available books: ");
            Console.WriteLine("9.Show late returns:");
            Console.WriteLine("10.Show the most borrowed books: ");
        }
    }
}
