﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class Reader
    {
		private string name;

		public string Name
		{
			get { return name; }
			set { name = value; }
		}
		private int id;

		public int Id
		{
			get { return id; }
			set { id = value; }
		}
		private int age;

		public int Age
		{
			get { return age; }
			set { age = value; }
		}
		private List<Book> books;

		public List<Book> Books
		{
			get { return books; }
			set { books = value; }
		}

        public Reader(string name, int id, int age)
        {
            Name = name;
            Id = id;
            Age = age;
            Books = new List<Book>();
        }

        public override string? ToString()
        {
			return $"{Name} {Id} {Age}";
        }
    }
}
