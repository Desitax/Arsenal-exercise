﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class Borrowing
    {
		private Reader reader;

		public Reader Reader
		{
			get { return reader; }
			set { reader = value; }
		}
		private Book book;

		public Book Book
		{
			get { return book; }
			set { book = value; }
		}
		private DateTime dateOfBorrowing;

		public DateTime DateOfBorrowing
		{
			get { return dateOfBorrowing; }
			set { dateOfBorrowing = value; }
		}
		private DateTime dateOfReturn;

		public DateTime DateOfReturn
		{
			get { return dateOfReturn; }
			set { dateOfReturn = value; }
		}

        public Borrowing(Reader reader, Book book, DateTime dateOfBorrowing, DateTime dateOfReturn)
        {
            Reader = reader;
            Book = book;
            DateOfBorrowing = dateOfBorrowing;
            DateOfReturn = dateOfReturn;
        }
    }
}
