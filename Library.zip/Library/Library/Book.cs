﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class Book
    {
		private string title;

		public string Title
		{
			get { return title; }
			set { title = value; }
		}
		private string author;

		public string Author
		{
			get { return author; }
			set { author = value; }
		}
		private string genre;

		public string Genre
		{
			get { return genre; }
			set { genre = value; }
		}
		private int countCopy;

		public int CountCopy
		{
			get { return countCopy; }
			set { countCopy = value; }
		}
		private int countBorrowed;

		public int CountBorrowed
		{
			get { return countBorrowed; }
			set { countBorrowed = value; }
		}

        public Book(string title, string author, string genre, int countCopy, int countBorrowed)
        {
            Title = title;
            Author = author;
            Genre = genre;
            CountCopy = countCopy;
            CountBorrowed = countBorrowed;
        }

        public override string? ToString()
        {
			return $"{Title} {Author} {Genre} {CountCopy} {CountBorrowed}";
        }
    }
}
