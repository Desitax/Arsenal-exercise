﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZdravkaProject
{
    public class Teacher
    {
        private int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public Subject subject { get; set; }

        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string surname;

        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }
        private int age;

        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        private string city;

        public string City
        {
            get { return city; }
            set { city = value; }
        }
        private string phoneNumber;

        public string PhoneNumber
        {
            get { return phoneNumber; }
            set { phoneNumber = value; }
        }

        private DateTime dateOfBirth;

        public DateTime DateOfBirth
        {
            get { return dateOfBirth; }
            set { dateOfBirth = value; }
        }
        private int yearsOfTeaching;

        public int YearsOfTeaching
        {
            get { return yearsOfTeaching; }
            set { yearsOfTeaching = value; }
        }


        public Teacher(int id,string name, string surname, int age, string city, string phoneNumber, DateTime dateOfBirth,int yearsOfTeaching)
        {
            Id= id;
            Name = name;
            Surname = surname;
            Age = age;
            City = city;
            PhoneNumber = phoneNumber;
            DateOfBirth = dateOfBirth;
            YearsOfTeaching= yearsOfTeaching;
        }
    }
}
