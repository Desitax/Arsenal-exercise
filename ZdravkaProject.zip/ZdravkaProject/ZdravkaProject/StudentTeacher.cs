﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZdravkaProject
{
    public class StudentTeacher
    {
		private int id;

		public int Id
		{
			get { return id; }
			set { id = value; }
		}
		public Student Student { get; set; }
		public Teacher Teacher { get; set; }
		private int yearsOfCollaborationWork;

        public StudentTeacher(int id, int yearsOfCollaborationWork)
        {
            Id = id;
            YearsOfCollaborationWork = yearsOfCollaborationWork;
        }

        public int YearsOfCollaborationWork
        {
			get { return yearsOfCollaborationWork; }
			set { yearsOfCollaborationWork = value; }
		}

	}
}
