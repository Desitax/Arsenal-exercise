﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZdravkaProject
{
    public class Subject
    {
		private int id;

		public int Id
		{
			get { return id; }
			set { id = value; }
		}

		private string name;

		public string Name
		{
			get { return name; }
			set { name = value; }
		}
		private decimal price;

		public decimal Price
		{
			get { return price; }
			set { price = value; }
		}
		private int duration;

        public Subject(int id, string name, decimal price, int duration)
        {
            Id = id;
            Name = name;
            Price = price;
            Duration = duration;
        }

        public int Duration
		{
			get { return duration; }
			set { duration = value; }
		}

	}
}
