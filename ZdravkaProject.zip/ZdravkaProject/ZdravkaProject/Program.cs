﻿namespace ZdravkaProject
{
    public class Program
    {
        static List<Subject> subjects = new List<Subject>();
        static List<Student> students = new List<Student>();
        static List<Teacher> teachers = new List<Teacher>();
        static List<StudentTeacher> studentTeachers = new List<StudentTeacher>();
        static List<Academy> academies = new List<Academy>();

        public static void Main(string[] args)
        {
            string command = "";

            while (command != "end")
            {
                ShowMenu();
                command = Console.ReadLine();

                switch (command)
                {
                    case "1":
                        AddStudent();
                        break;
                    case "2":
                        AddTeacher();
                        break;
                    case "3":
                        AddSubject();
                        break;
                    case "4":
                        ShowAllStudents();
                        break;
                    case "5":
                        ShowAllSubjects();
                        break;
                    case "end":
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }
        static void ShowMenu()
        {
            Console.Clear();
            Console.WriteLine("Choose number: ");
            Console.WriteLine("1. Add new student: ");
            Console.WriteLine("2. Add new teacher: ");
            Console.WriteLine("3. Add new subject: ");
            Console.WriteLine("4. Show all students: ");
            Console.WriteLine("5. Show all subects: ");
        }
        static void AddStudent()
        {
            Console.WriteLine("Enter info about student: ");

            Console.WriteLine("Enter student id: ");
            int id = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter student name: ");
            string name = Console.ReadLine();

            Console.WriteLine("Enter student surname: ");
            string surname = Console.ReadLine();

            Console.WriteLine("Enter student age: ");
            int age = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter student city: ");
            string city = Console.ReadLine();

            Console.WriteLine("Enter student dateOfBirth: ");
            DateTime dateOfBirth = DateTime.Now;

            Student student = new Student(id, name, surname, age, city, dateOfBirth);
            students.Add(student);
        }
        static void AddTeacher()
        {
            Console.WriteLine("Enter info about teacher: ");

            Console.WriteLine("Enter teacher id: ");
            int id = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter teacher name: ");
            string name = Console.ReadLine();

            Console.WriteLine("Enter teacher surname: ");
            string surname = Console.ReadLine();

            Console.WriteLine("Enter teacher age: ");
            int age = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter teacher city: ");
            string city = Console.ReadLine();

            Console.WriteLine("Enter teacher phoneNumber:");
            string phoneNumber= Console.ReadLine();

            Console.WriteLine("Enter teacher dateOfBirth: ");
            DateTime dateOfBirth = DateTime.Now;

            Console.WriteLine("Enter teacher yearsOfTeaching: ");
            int yearsOfTeaching = int.Parse(Console.ReadLine());

            Teacher teacher = new Teacher(id, name, surname, age, city, phoneNumber, dateOfBirth, yearsOfTeaching);
            teachers.Add(teacher);
        }
        static void AddSubject()
        {
            Console.WriteLine("Enter info about subject: ");

            Console.WriteLine("Enter subject id: ");
            int id = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter subject name: ");
            string name = Console.ReadLine();

            Console.WriteLine("Enter subject price: ");
            decimal price = decimal.Parse(Console.ReadLine());

            Console.WriteLine("Enter subject duration: ");
            int duration = int.Parse(Console.ReadLine());

            Subject subject= new Subject(id, name, price, duration);
            subjects.Add(subject);
        }
        static void ShowAllStudents()
        {
            foreach (var student in students)
            {
                Console.WriteLine($"ID: {student.Id}, Name: {student.Name}, Surname: {student.Surname}, Age: {student.Age}, City: {student.City}, DOB: {student.DateOfBirth.ToShortDateString()}");
            }
            Console.ReadLine();
        }
        static void ShowAllSubjects()
        {
            foreach(var subject in subjects)
            {
                Console.WriteLine($"ID: {subject.Id},Name: {subject.Name}, Price: {subject.Price},Duration: {subject.Duration}");

            }
            Console.ReadLine();
        }
    }
}
   






