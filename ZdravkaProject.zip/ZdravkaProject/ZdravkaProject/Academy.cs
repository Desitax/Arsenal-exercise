﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZdravkaProject
{
    public class Academy
    {
		private int id;

		public int Id
		{
			get { return id; }
			set { id = value; }
		}

		private string name;

        public string Name
		{
			get { return name; }
			set { name = value; }
		}
        public Student Student { get; set; }
		public Teacher Teacher { get; set; }
        public Academy(int id, string name)
        {
            Id = id;
            Name = name;
        }
    }
}
