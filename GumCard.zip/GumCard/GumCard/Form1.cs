namespace GumCard
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.Add("Gym");
            comboBox1.Items.Add("Boxin");
            comboBox1.Items.Add("Yoga");
            comboBox1.Items.Add("Zumba");
            comboBox1.Items.Add("Dances");
            comboBox1.Items.Add("Pilates");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Dictionary<string, double> malePrices = new Dictionary<string, double>
            {
                { "Gym", 42 },
                { "Boxing", 41 },
                { "Yoga", 45 },
                { "Zumba", 34 },
                { "Dances", 51 },
                { "Pilates", 39 }
            };

            Dictionary<string, double> femalePrices = new Dictionary<string, double>
            {
                { "Gym", 35 },
                { "Boxing", 37 },
                { "Yoga", 42 },
                { "Zumba", 31 },
                { "Dances", 53 },
                { "Pilates", 37 }
            };
            double money = double.Parse(textBox1.Text);
            string gender = radioButton1.ToString();
            int age = int.Parse(textBox2.Text);
            string sport = comboBox1.SelectedItem.ToString();

            double price = 0;

            if (radioButton1.Checked)
            {
                price = malePrices[sport];

            }
            else if (radioButton3.Checked)
            {
                price = femalePrices[sport];
            }


            if (age <= 19)
                price *= 0.80;


            if (money >= price)
            {
                label5.Text = $"You purchased a 1 month pass for {sport}.";
            }
            else
            {
                double diff = price - money;
                label5.Text = $"You don't have enough money! You need ${diff:F2} more.";
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
    

