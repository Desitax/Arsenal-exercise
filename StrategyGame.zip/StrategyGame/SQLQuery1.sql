CREATE DATABASE StrategyGame

CREATE TABLE Players(
player_id INT PRIMARY KEY IDENTITY,
username NVARCHAR(50),
email NVARCHAR(50),
createdAt DATETIME NOT NULL
);

INSERT INTO Players (username, email, createdAt)
VALUES
('PlayerOne', 'player1@example.com', GETDATE()),
('PlayerTwo', 'player2@example.com', GETDATE());

CREATE TABLE Factions(
faction_id INT PRIMARY KEY IDENTITY,
name NVARCHAR(100),
description NVARCHAR(255)
)

INSERT INTO Factions (name, description)
VALUES
('Humans', 'Balanced race with strong economy.'),
('Orcs', 'Strong melee units, weak defenses.');

CREATE TABLE PlayerFactions(
playerfaction_id INT PRIMARY KEY IDENTITY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
faction_id INT FOREIGN KEY REFERENCES Factions(faction_id),
startDate DATETIME NOT NULL
);

INSERT INTO PlayerFactions (player_id, faction_id, startDate) 
VALUES
(1, 1, GETDATE()),
(2, 2, GETDATE());

CREATE TABLE Buildings(
building_id INT PRIMARY KEY IDENTITY,
name NVARCHAR(50),
description NVARCHAR(255),
buildTime INT,
faction_id INT FOREIGN KEY REFERENCES Factions(faction_id)
);

INSERT INTO Buildings (name, description, buildTime, faction_id)
VALUES
('Barracks', 'Trains infantry.', 60, 1),
('Farm', 'Produces food.', 30, 1);

CREATE TABLE PlayerBuildings(
playerBuilding_id INT PRIMARY KEY IDENTITY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
building_id INT FOREIGN KEY REFERENCES Buildings(building_id),
level INT NOT NULL,
builtAt DATETIME NOT NULL
);

INSERT INTO PlayerBuildings (player_id, building_id, level, builtAt) 
VALUES
(1, 1, 1, GETDATE()),
(1, 2, 2, GETDATE());

CREATE TABLE Units(
unit_id INT PRIMARY KEY IDENTITY,
name NVARCHAR(50),
attackPower INT NOT NULL,
defensePower INT NOT NULL,
trainingTime INT NOT NULL,
faction_id INT FOREIGN KEY REFERENCES Factions(faction_id)
);

INSERT INTO Units (name, attackPower, defensePower, trainingTime, faction_id)
VALUES
('Swordsman', 10, 5, 45, 1),
('Archer', 7, 3, 30, 1);

CREATE TABLE PlayerUnits(
playerunit_id INT PRIMARY KEY IDENTITY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
unit_id INT FOREIGN KEY REFERENCES Units(unit_id),
quantity INT NOT NULL
);

INSERT INTO PlayerUnits (player_id, unit_id, quantity)
VALUES
(1, 1, 10),
(1, 2, 5);

CREATE TABLE Resources(
resours_id INT PRIMARY KEY IDENTITY,
name NVARCHAR(50),
description NVARCHAR(255)
);

INSERT INTO Resources (name, description)
VALUES
('Gold', 'Used for building and training.'),
('Food', 'Required for units to survive.');

CREATE TABLE PlayerResources(
playerResources_id INT PRIMARY KEY IDENTITY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
resours_id INT FOREIGN KEY REFERENCES Resources(resours_id),
amount INT
);

INSERT INTO PlayerResources (player_id, resours_id, amount)
VALUES
(1, 1, 1000),
(1, 2, 500);

CREATE TABLE Battles(
battle_id INT PRIMARY KEY IDENTITY,
attackerId INT FOREIGN KEY (AttackerId) REFERENCES Players(player_id),
defenderId INT  FOREIGN KEY (DefenderId) REFERENCES Players(player_id),
startedAt DATETIME NOT NULL,
endedAt DATETIME,
Result INT NOT NULL
);

INSERT INTO Battles (attackerId, defenderId, startedAt, endedAt, Result) 
VALUES
(1, 2, GETDATE(), DATEADD(MINUTE, 10, GETDATE()), 0); 

CREATE TABLE BattleUnits(
battleUnits_id INT PRIMARY KEY IDENTITY,
battle_id INT FOREIGN KEY REFERENCES Battles(battle_id),
unit_id INT FOREIGN KEY REFERENCES Units(unit_id),
player_id INT FOREIGN KEY REFERENCES Players(player_id),
quantity INT NOT NULL,
);

INSERT INTO BattleUnits (battle_id, unit_id, player_id, quantity) 
VALUES
(1, 1, 1, 5),
(1, 2, 2, 4);

CREATE TABLE Maps(
map_id INT PRIMARY KEY IDENTITY,
name NVARCHAR(100),
sizeX INT NOT NULL,
sizeY INT NOT NULL,
description NVARCHAR(255)
);

INSERT INTO Maps (name, sizeX, sizeY, description) 
VALUES
('Valley of Kings', 100, 100, 'A balanced map with hills and forests.');

CREATE TABLE PlayerLocations(
playerLocations_id INT PRIMARY KEY IDENTITY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
map_id INT FOREIGN KEY REFERENCES Maps(map_id),
X INT NOT NULL,
Y INT NOT NULL,
);

INSERT INTO PlayerLocations (player_id, map_id, X, Y)
VALUES
(1, 1, 10, 20),
(2, 1, 90, 80);

CREATE TABLE Technologies(
technologies_id INT PRIMARY KEY IDENTITY,
Name NVARCHAR(100) NOT NULL,
description NVARCHAR(255),
researchTime INT NOT NULL
);

INSERT INTO Technologies (Name, description, researchTime)
VALUES
('Advanced Metallurgy', 'Increases attack by 10%', 120),
('Efficient Farming', 'Increases food production by 20%', 90);

CREATE TABLE PlayerTechnologies (
playerTechnologies_id INT PRIMARY KEY IDENTITY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
technologies_id INT FOREIGN KEY REFERENCES Technologies(technologies_id),
isResearched BIT NOT NULL,
researchedAt DATETIME,
);

INSERT INTO PlayerTechnologies (player_id, technologies_id, isResearched, researchedAt)
VALUES
(1, 1, 1, GETDATE()),
(1, 2, 0, NULL);