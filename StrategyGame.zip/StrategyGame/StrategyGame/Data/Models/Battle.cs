﻿using System;
using System.Collections.Generic;

namespace StrategyGame.Data.Models;

public partial class Battle
{
    public int BattleId { get; set; }

    public int? AttackerId { get; set; }

    public int? DefenderId { get; set; }

    public DateTime StartedAt { get; set; }

    public DateTime? EndedAt { get; set; }

    public int Result { get; set; }

    public virtual Player? Attacker { get; set; }

    public virtual ICollection<BattleUnit> BattleUnits { get; set; } = new List<BattleUnit>();

    public virtual Player? Defender { get; set; }
}
