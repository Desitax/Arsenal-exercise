﻿using System;
using System.Collections.Generic;

namespace StrategyGame.Data.Models;

public partial class PlayerResource
{
    public int PlayerResourcesId { get; set; }

    public int? PlayerId { get; set; }

    public int? ResoursId { get; set; }

    public int? Amount { get; set; }

    public virtual Player? Player { get; set; }

    public virtual Resource? Resours { get; set; }
}
