﻿using System;
using System.Collections.Generic;

namespace StrategyGame.Data.Models;

public partial class PlayerTechnology
{
    public int PlayerTechnologiesId { get; set; }

    public int? PlayerId { get; set; }

    public int? TechnologiesId { get; set; }

    public bool IsResearched { get; set; }

    public DateTime? ResearchedAt { get; set; }

    public virtual Player? Player { get; set; }

    public virtual Technology? Technologies { get; set; }
}
