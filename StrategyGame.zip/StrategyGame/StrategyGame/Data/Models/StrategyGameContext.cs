﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace StrategyGame.Data.Models;

public partial class StrategyGameContext : DbContext
{
    public StrategyGameContext()
    {
    }

    public StrategyGameContext(DbContextOptions<StrategyGameContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Battle> Battles { get; set; }

    public virtual DbSet<BattleUnit> BattleUnits { get; set; }

    public virtual DbSet<Building> Buildings { get; set; }

    public virtual DbSet<Faction> Factions { get; set; }

    public virtual DbSet<Map> Maps { get; set; }

    public virtual DbSet<Player> Players { get; set; }

    public virtual DbSet<PlayerBuilding> PlayerBuildings { get; set; }

    public virtual DbSet<PlayerFaction> PlayerFactions { get; set; }

    public virtual DbSet<PlayerLocation> PlayerLocations { get; set; }

    public virtual DbSet<PlayerResource> PlayerResources { get; set; }

    public virtual DbSet<PlayerTechnology> PlayerTechnologies { get; set; }

    public virtual DbSet<PlayerUnit> PlayerUnits { get; set; }

    public virtual DbSet<Resource> Resources { get; set; }

    public virtual DbSet<Technology> Technologies { get; set; }

    public virtual DbSet<Unit> Units { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=STUDENT16;Initial Catalog=StrategyGame;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Battle>(entity =>
        {
            entity.HasKey(e => e.BattleId).HasName("PK__Battles__E3EE0197A5409180");

            entity.Property(e => e.BattleId).HasColumnName("battle_id");
            entity.Property(e => e.AttackerId).HasColumnName("attackerId");
            entity.Property(e => e.DefenderId).HasColumnName("defenderId");
            entity.Property(e => e.EndedAt)
                .HasColumnType("datetime")
                .HasColumnName("endedAt");
            entity.Property(e => e.StartedAt)
                .HasColumnType("datetime")
                .HasColumnName("startedAt");

            entity.HasOne(d => d.Attacker).WithMany(p => p.BattleAttackers)
                .HasForeignKey(d => d.AttackerId)
                .HasConstraintName("FK__Battles__attacke__52593CB8");

            entity.HasOne(d => d.Defender).WithMany(p => p.BattleDefenders)
                .HasForeignKey(d => d.DefenderId)
                .HasConstraintName("FK__Battles__defende__534D60F1");
        });

        modelBuilder.Entity<BattleUnit>(entity =>
        {
            entity.HasKey(e => e.BattleUnitsId).HasName("PK__BattleUn__1D0E660A5881EE02");

            entity.Property(e => e.BattleUnitsId).HasColumnName("battleUnits_id");
            entity.Property(e => e.BattleId).HasColumnName("battle_id");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");
            entity.Property(e => e.Quantity).HasColumnName("quantity");
            entity.Property(e => e.UnitId).HasColumnName("unit_id");

            entity.HasOne(d => d.Battle).WithMany(p => p.BattleUnits)
                .HasForeignKey(d => d.BattleId)
                .HasConstraintName("FK__BattleUni__battl__5629CD9C");

            entity.HasOne(d => d.Player).WithMany(p => p.BattleUnits)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__BattleUni__playe__5812160E");

            entity.HasOne(d => d.Unit).WithMany(p => p.BattleUnits)
                .HasForeignKey(d => d.UnitId)
                .HasConstraintName("FK__BattleUni__unit___571DF1D5");
        });

        modelBuilder.Entity<Building>(entity =>
        {
            entity.HasKey(e => e.BuildingId).HasName("PK__Building__9C9FBF7F28E3EC59");

            entity.Property(e => e.BuildingId).HasColumnName("building_id");
            entity.Property(e => e.BuildTime).HasColumnName("buildTime");
            entity.Property(e => e.Description)
                .HasMaxLength(255)
                .HasColumnName("description");
            entity.Property(e => e.FactionId).HasColumnName("faction_id");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .HasColumnName("name");

            entity.HasOne(d => d.Faction).WithMany(p => p.Buildings)
                .HasForeignKey(d => d.FactionId)
                .HasConstraintName("FK__Buildings__facti__3F466844");
        });

        modelBuilder.Entity<Faction>(entity =>
        {
            entity.HasKey(e => e.FactionId).HasName("PK__Factions__FCC09831C827D930");

            entity.Property(e => e.FactionId).HasColumnName("faction_id");
            entity.Property(e => e.Description)
                .HasMaxLength(255)
                .HasColumnName("description");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Map>(entity =>
        {
            entity.HasKey(e => e.MapId).HasName("PK__Maps__52A78819F2FA505E");

            entity.Property(e => e.MapId).HasColumnName("map_id");
            entity.Property(e => e.Description)
                .HasMaxLength(255)
                .HasColumnName("description");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
            entity.Property(e => e.SizeX).HasColumnName("sizeX");
            entity.Property(e => e.SizeY).HasColumnName("sizeY");
        });

        modelBuilder.Entity<Player>(entity =>
        {
            entity.HasKey(e => e.PlayerId).HasName("PK__Players__44DA120C717A4D83");

            entity.Property(e => e.PlayerId).HasColumnName("player_id");
            entity.Property(e => e.CreatedAt)
                .HasColumnType("datetime")
                .HasColumnName("createdAt");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .HasColumnName("email");
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .HasColumnName("username");
        });

        modelBuilder.Entity<PlayerBuilding>(entity =>
        {
            entity.HasKey(e => e.PlayerBuildingId).HasName("PK__PlayerBu__42990F8DBF99DF03");

            entity.Property(e => e.PlayerBuildingId).HasColumnName("playerBuilding_id");
            entity.Property(e => e.BuildingId).HasColumnName("building_id");
            entity.Property(e => e.BuiltAt)
                .HasColumnType("datetime")
                .HasColumnName("builtAt");
            entity.Property(e => e.Level).HasColumnName("level");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");

            entity.HasOne(d => d.Building).WithMany(p => p.PlayerBuildings)
                .HasForeignKey(d => d.BuildingId)
                .HasConstraintName("FK__PlayerBui__build__4316F928");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerBuildings)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerBui__playe__4222D4EF");
        });

        modelBuilder.Entity<PlayerFaction>(entity =>
        {
            entity.HasKey(e => e.PlayerfactionId).HasName("PK__PlayerFa__A2A73AD5C63F9AA7");

            entity.Property(e => e.PlayerfactionId).HasColumnName("playerfaction_id");
            entity.Property(e => e.FactionId).HasColumnName("faction_id");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");
            entity.Property(e => e.StartDate)
                .HasColumnType("datetime")
                .HasColumnName("startDate");

            entity.HasOne(d => d.Faction).WithMany(p => p.PlayerFactions)
                .HasForeignKey(d => d.FactionId)
                .HasConstraintName("FK__PlayerFac__facti__3C69FB99");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerFactions)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerFac__playe__3B75D760");
        });

        modelBuilder.Entity<PlayerLocation>(entity =>
        {
            entity.HasKey(e => e.PlayerLocationsId).HasName("PK__PlayerLo__31F306A57ADF140B");

            entity.Property(e => e.PlayerLocationsId).HasColumnName("playerLocations_id");
            entity.Property(e => e.MapId).HasColumnName("map_id");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");

            entity.HasOne(d => d.Map).WithMany(p => p.PlayerLocations)
                .HasForeignKey(d => d.MapId)
                .HasConstraintName("FK__PlayerLoc__map_i__5DCAEF64");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerLocations)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerLoc__playe__5CD6CB2B");
        });

        modelBuilder.Entity<PlayerResource>(entity =>
        {
            entity.HasKey(e => e.PlayerResourcesId).HasName("PK__PlayerRe__A2BEF6E626DDD9FB");

            entity.Property(e => e.PlayerResourcesId).HasColumnName("playerResources_id");
            entity.Property(e => e.Amount).HasColumnName("amount");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");
            entity.Property(e => e.ResoursId).HasColumnName("resours_id");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerResources)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerRes__playe__4E88ABD4");

            entity.HasOne(d => d.Resours).WithMany(p => p.PlayerResources)
                .HasForeignKey(d => d.ResoursId)
                .HasConstraintName("FK__PlayerRes__resou__4F7CD00D");
        });

        modelBuilder.Entity<PlayerTechnology>(entity =>
        {
            entity.HasKey(e => e.PlayerTechnologiesId).HasName("PK__PlayerTe__A839FEBE0A022D86");

            entity.Property(e => e.PlayerTechnologiesId).HasColumnName("playerTechnologies_id");
            entity.Property(e => e.IsResearched).HasColumnName("isResearched");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");
            entity.Property(e => e.ResearchedAt)
                .HasColumnType("datetime")
                .HasColumnName("researchedAt");
            entity.Property(e => e.TechnologiesId).HasColumnName("technologies_id");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerTechnologies)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerTec__playe__628FA481");

            entity.HasOne(d => d.Technologies).WithMany(p => p.PlayerTechnologies)
                .HasForeignKey(d => d.TechnologiesId)
                .HasConstraintName("FK__PlayerTec__techn__6383C8BA");
        });

        modelBuilder.Entity<PlayerUnit>(entity =>
        {
            entity.HasKey(e => e.PlayerunitId).HasName("PK__PlayerUn__2185E52BC563BB7C");

            entity.Property(e => e.PlayerunitId).HasColumnName("playerunit_id");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");
            entity.Property(e => e.Quantity).HasColumnName("quantity");
            entity.Property(e => e.UnitId).HasColumnName("unit_id");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerUnits)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerUni__playe__48CFD27E");

            entity.HasOne(d => d.Unit).WithMany(p => p.PlayerUnits)
                .HasForeignKey(d => d.UnitId)
                .HasConstraintName("FK__PlayerUni__unit___49C3F6B7");
        });

        modelBuilder.Entity<Resource>(entity =>
        {
            entity.HasKey(e => e.ResoursId).HasName("PK__Resource__CE8EFC5F54E03414");

            entity.Property(e => e.ResoursId).HasColumnName("resours_id");
            entity.Property(e => e.Description)
                .HasMaxLength(255)
                .HasColumnName("description");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Technology>(entity =>
        {
            entity.HasKey(e => e.TechnologiesId).HasName("PK__Technolo__181FA18146FCC28C");

            entity.Property(e => e.TechnologiesId).HasColumnName("technologies_id");
            entity.Property(e => e.Description)
                .HasMaxLength(255)
                .HasColumnName("description");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ResearchTime).HasColumnName("researchTime");
        });

        modelBuilder.Entity<Unit>(entity =>
        {
            entity.HasKey(e => e.UnitId).HasName("PK__Units__D3AF5BD7EDCFCF4C");

            entity.Property(e => e.UnitId).HasColumnName("unit_id");
            entity.Property(e => e.AttackPower).HasColumnName("attackPower");
            entity.Property(e => e.DefensePower).HasColumnName("defensePower");
            entity.Property(e => e.FactionId).HasColumnName("faction_id");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .HasColumnName("name");
            entity.Property(e => e.TrainingTime).HasColumnName("trainingTime");

            entity.HasOne(d => d.Faction).WithMany(p => p.Units)
                .HasForeignKey(d => d.FactionId)
                .HasConstraintName("FK__Units__faction_i__45F365D3");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
