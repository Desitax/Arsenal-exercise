﻿using System;
using System.Collections.Generic;

namespace StrategyGame.Data.Models;

public partial class PlayerFaction
{
    public int PlayerfactionId { get; set; }

    public int? PlayerId { get; set; }

    public int? FactionId { get; set; }

    public DateTime StartDate { get; set; }

    public virtual Faction? Faction { get; set; }

    public virtual Player? Player { get; set; }
}
