﻿using System;
using System.Collections.Generic;

namespace StrategyGame.Data.Models;

public partial class Resource
{
    public int ResoursId { get; set; }

    public string? Name { get; set; }

    public string? Description { get; set; }

    public virtual ICollection<PlayerResource> PlayerResources { get; set; } = new List<PlayerResource>();
}
