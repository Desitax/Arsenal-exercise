﻿using Microsoft.EntityFrameworkCore;
using PharmacyZad.Data.Models;

namespace PharmacyZad
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            PharmacyDbContext context = new PharmacyDbContext();
            ShowMenu();

            string command = Console.ReadLine();

            switch (command)
            {
                case "1":
                    await ShowAllMedicines(context);
                    break;
                case "2":
                    await ShowMedicinesWithAssertenQuantityInStock(context);
                    break;
                case "3":
                    await ShowTop3MostExpensiveMed(context);
                    break;
                case "4":
                    await ShowAllEmployees(context);
                    break;
                case "5":
                    await ShowAllOrdersFromEmployee(context);
                    break;
                case "6":
                    await ShowMedicineWithNoQuantity(context);
                    break;
                case "7":
                    await ShowDoctorsDescribingPrescription(context);
                    break;
                case "8":
                    await ShowPatientWirhPrescriptionByAssertDoctor(context);
                    break;
                case "9":
                    await AllPriceOrders(context);
                    break;
                default:
                    Console.WriteLine("Invalid command!");
                    break;

            }

        }
        public static void ShowMenu()
        {
            Console.Clear();
            Console.WriteLine("===== Меню на аптеката =====");
            Console.WriteLine("Изберете опция: ");
            Console.WriteLine("1. Показване на всички лекарства");
            Console.WriteLine("2. Показване на лекарства с наличност под 50");
            Console.WriteLine("3. Показване на най-скъпите 3 лекарства");
            Console.WriteLine("4. Показване на всички служители");
            Console.WriteLine("5. Показване на поръчки от даден доставчик");
            Console.WriteLine("6. Показване на лекарства с изчерпано количество");
            Console.WriteLine("7. Показване на всички лекари, писали рецепти");
            Console.WriteLine("8. Показване на пациентите, на които лекар е изписвал лекарства");
            Console.WriteLine("9. Показване на общата стойност на всички поръчки");
            Console.WriteLine("0. Изход");
        }
        public static async Task ShowAllMedicines(PharmacyDbContext context)
        {
            var medicines = await context.Medicines.ToListAsync<Medicine>();
            foreach (var medicine in medicines)
            {
                Console.WriteLine(medicine.Name);
            }
        }
        public static async Task ShowMedicinesWithAssertenQuantityInStock(PharmacyDbContext context)
        {
            var medicines = await context.Medicines.Where(m=>m.QuantityInStock<50).ToListAsync<Medicine>();
            foreach(var medicine in medicines)
            {
                Console.WriteLine(medicine.Name);
            }
        }
        public static async Task ShowTop3MostExpensiveMed(PharmacyDbContext context)
        {
            var medicines=await context.Medicines.OrderByDescending(m=>m.Price).Take(3).ToListAsync<Medicine>();
            foreach (var medicine in medicines)
            {
                Console.WriteLine(medicine.Name);
            }
        }
        public static async Task ShowAllEmployees(PharmacyDbContext context)
        {
            var employees=await context.Employees.ToListAsync<Employee>();
            foreach (var employee in employees)
            {
                Console.WriteLine(employee.Name);
            }
        }
        public static async Task ShowAllOrdersFromEmployee(PharmacyDbContext context)
        {
            Console.WriteLine("Enter employee name: ");
            string name = Console.ReadLine();
            var orders=await context.Orders.Where(o=>o.SupplierName==name).ToListAsync<Order>();
            if (orders.Count == 0)
            {
                Console.WriteLine("No orders!");
            }
            else
            {
                foreach (var order in orders)
                {
                    Console.WriteLine($"{order.SupplierName} {order.OrderDate} {order.QuantityOrdered}");
                }
            }
        }
        public static async Task ShowMedicineWithNoQuantity(PharmacyDbContext context)
        {
            var medicines=await context.Medicines.Where(m=>m.QuantityInStock==0).ToListAsync<Medicine>();
            foreach (var medicine in medicines)
            {
                Console.WriteLine(medicine.Name);
            }
        }
        public static async Task ShowDoctorsDescribingPrescription(PharmacyDbContext context)
        {
            var doctors = await context.Prescriptions.Select(p => p.DoctorName).ToListAsync();
            foreach (var doctor in doctors)
            {
                Console.WriteLine(doctor);
            }
        }
        public static async Task ShowPatientWirhPrescriptionByAssertDoctor(PharmacyDbContext context)
        {
            Console.WriteLine("Enter doctor name: ");
            string name=Console.ReadLine();
            var patients=await context.Prescriptions.Where(p=>p.DoctorName==name).ToListAsync();
            foreach (var patient in patients)
            {
                Console.WriteLine(patient.PatientName);
            }
        }
        public static async Task AllPriceOrders(PharmacyDbContext context)
        {
            var allprice=await context.Orders.SumAsync(o=>o.QuantityOrdered*context.Medicines.Where(m=>m.Id==o.Id).Select(m=>m.Price).FirstOrDefault());
            Console.WriteLine(allprice);
        }
    }

}

