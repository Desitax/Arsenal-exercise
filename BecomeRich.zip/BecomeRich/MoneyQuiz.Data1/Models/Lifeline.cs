﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Data.Models
{
    public class Lifeline
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey(nameof(PlayerGameSession))]
        public int PlayerGameSessionId { get; set; }
        public PlayerGameSession PlayerGameSession { get; set; }
        [Required]
        public string Type { get; set; }
        [ForeignKey(nameof(Questions))]
        public int? UsedOnQuestionId { get; set; }
        public Questions UsedOnQuestion { get; set; }
    }
}
