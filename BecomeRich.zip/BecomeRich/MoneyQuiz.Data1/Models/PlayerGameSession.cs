﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Data.Models
{
    public class PlayerGameSession
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey(nameof(Player))]
        public int PlayerId { get; set; }
        public Player Player { get; set; }
        [ForeignKey(nameof(Session))]
        public int SessionId { get; set; }
        public GameSession Session { get; set; }
        public ICollection<PlayerAnswer> PlayerAnswers { get; set; }
        public ICollection<Lifeline> Lifelines { get; set; }
    }
}
