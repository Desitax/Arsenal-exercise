﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Data.Models
{
    public class PlayerAnswer
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey(nameof(PlayerGameSession))]
        public int PlayerSessionId { get; set; }
        public PlayerGameSession PlayerGameSession { get; set; }
        [ForeignKey(nameof(Answer))]
        public int AnswerId { get; set; }
        public Answer Answer { get; set; }
        
        public bool IsCorrect { get; set; }
    }
}
