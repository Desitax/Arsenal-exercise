﻿using MoneyQuiz.ConsoleApp1.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.ConsoleApp1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Display display = new Display();
            display.StartUp();
        }
    }
}
