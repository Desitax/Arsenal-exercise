﻿using MoneyQuiz.Core1;
using MoneyQuiz.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.ConsoleApp1.Views
{
    public class Display
    {
        AnswerController answerController = new AnswerController();
        LifelineController lifelineController = new LifelineController();
        PlayerController playerController = new PlayerController();
        QuestionController questionController = new QuestionController();

        string command = Console.ReadLine();
        public void StartUp()
        {
            ShowMenu();
            while(true)
            {
                switch (command)
                {
                    case "1":
                        Console.Write("Enter question text: ");
                        var text = Console.ReadLine();

                        Console.Write("Enter amount: ");
                        decimal amount = decimal.Parse(Console.ReadLine());

                        Questions questions = new Questions();
                        questionController.AddQuestions(questions);
                        break;
                    case "2":

                        Console.Write("Enter question ID: ");
                        int qId = int.Parse(Console.ReadLine());

                        var answers = new List<Answer>();
                        for (int i = 1; i <= 4; i++)
                        {
                            Console.Write($"Answer {i} text: ");
                            string ansText = Console.ReadLine();

                            Console.Write("Is it correct? (true/false): ");
                            bool isCorrect = bool.Parse(Console.ReadLine());

                            Answer answer1 = new Answer();
                            answers.Add(answer1);
                        }
                        answerController.AddAnswersToQuestion(qId, answers);
                        break;
                    case "3":
                        Console.Write("Enter question ID to edit: ");
                        int qEditId = int.Parse(Console.ReadLine());

                        Console.Write("Enter new question text: ");
                        string newText = Console.ReadLine();

                        Console.Write("Enter new amount: ");
                        decimal newAmount = decimal.Parse(Console.ReadLine());

                        questionController.UpdateQuestion(qEditId, newText, newAmount);
                        break;
                    case "4":
                        Console.Write("Enter answer ID: ");
                        int aId = int.Parse(Console.ReadLine());

                        Console.Write("Enter new answer text: ");
                        string aText = Console.ReadLine();

                        Console.Write("Is it correct? (true/false): ");
                        bool isCorrectNew = bool.Parse(Console.ReadLine());

                        Console.Write("Enter question ID: ");
                        int qid = int.Parse(Console.ReadLine());

                        Answer answer=new Answer();
                        answerController.UpdateAnswer(aId,aText,isCorrectNew,qid);
                        break;
                    case "5":
                        Console.Write("Enter lifeline ID to delete: ");
                        int jId = int.Parse(Console.ReadLine());

                        lifelineController.DeleteLifeline(jId);
                        break;
                    case "6":
                        Console.Write("Enter player name: ");
                        string name = Console.ReadLine();

                        Console.Write("Enter email: ");
                        string email = Console.ReadLine();

                        playerController.AddPlayer(name, email);
                        break;

                    case "7":
                        var question = questionController.GetQuestionsAboveAmount();
                        Console.WriteLine("\nQuestions over 3000:");

                        foreach (var q in question)
                            Console.WriteLine("- " + q);
                        break;
                    case "8":
                        var qWithAns = questionController.GetQuestionsWithAllAnswers();
                        foreach (var item in qWithAns)
                        {
                            Console.WriteLine("Question: " + item.QuestionText);
                            foreach (var ans in item.Answers)
                                Console.WriteLine(" - " + ans);
                            Console.WriteLine();
                        }
                        Console.ReadKey();
                        break;

                    case "9":
                        Console.Write("Enter amount: ");
                        decimal exactAmount = decimal.Parse(Console.ReadLine());
                        var qCorrect = questionController.GetQuestionsWithCorrectAnswerByAmount(exactAmount);
                        foreach (var item in qCorrect)
                            Console.WriteLine($"Question: {item.QuestionText}\nCorrect answer: {item.Answers}\n");
                        break;

                    case "0":
                        return;

                    default:
                        Console.WriteLine("Invalid choice! Press any key...");
                        break;

                }
                command = Console.ReadLine();
            }
          
        }
        void ShowMenu()
        {
            Console.Clear();
            Console.WriteLine("=== MAIN MENU ===");
            Console.WriteLine("1. Add a question");
            Console.WriteLine("2. Add 4 answers to a question");
            Console.WriteLine("3. Edit a question");
            Console.WriteLine("4. Edit an answer");
            Console.WriteLine("5. Delete a lifeline");
            Console.WriteLine("6. Add a player");
            Console.WriteLine("7. Show questions with amount > 3000");
            Console.WriteLine("8. Show questions with all possible answers");
            Console.WriteLine("9. Show questions and correct answers by amount");
            Console.WriteLine("0. Exit");
            Console.Write("Choice: ");
        }
        

    }
}
