﻿using MoneyQuiz.ConsoleApp.Data.Models;
using MoneyQuiz.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Core1
{
    public class LifelineController
    {
        MoneyQuizDbContext context = new MoneyQuizDbContext();
        public void AddLifeline(Lifeline lifeline)
        {
            context.Lifelines.Add(lifeline);
            context.SaveChanges();
        }
        public List<Lifeline> ReadLifeline()
        {
            return context.Lifelines.ToList();
        }
        public void UpdateLifeline(int id, int PlayerGameSessionId, string Type, int? UsedOnQuestionId)
        {
            var lifeline = context.Lifelines.Find(id);
            if (lifeline != null)
            {
                lifeline.PlayerGameSessionId = PlayerGameSessionId;
                lifeline.Type = Type;
                lifeline.UsedOnQuestionId = UsedOnQuestionId;
                context.Lifelines.Update(lifeline);
                context.SaveChanges();
            }
        }
        public void DeleteLifeline(int id)
        {
            var lifeline = context.Lifelines.Find(id);
            if (lifeline != null)
            {
                context.Lifelines.Remove(lifeline);
            }
        }

    }
}
