﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ValueGeneration;
using MoneyQuiz.ConsoleApp.Data.Models;
using MoneyQuiz.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Core1
{
    public class AnswerController
    {
        MoneyQuizDbContext context=new MoneyQuizDbContext();
        public void AddAnswer(Answer answer)
        {
            context.Answers.Add(answer);    
            context.SaveChanges();
        }
        public List<Answer> ReadAnswer()
        {
            return context.Answers.ToList();
        }
        public void UpdateAnswer(int id,string AnswerText,bool IsCorrect, int QuestionId)
        {
            var answer = context.Answers.Find(id);
            if (answer != null)
            {
                answer.AnswerText = AnswerText;
                answer.IsCorrect = IsCorrect;
                answer.QuestionId = QuestionId;
                context.Answers.Update(answer);
                context.SaveChanges();
            }
        }
        public void DeleteAnswer(int id)
        {
            var answer = context.Answers.Find(id);
            if (answer != null)
            {
                context.Answers.Remove(answer);
            }
        }

        public void AddAnswersToQuestion(int questionId, List<Answer> answers)
        {
            if (answers.Count != 4)
                throw new ArgumentException("Add exactly 4 answers");

            var question = context.Questions.Find(questionId);
            if (question == null)
                throw new Exception("Such answer doesn't exist");

            foreach (var ans in answers)
            {
                context.Answers.Add(new Answer
                {
                    AnswerText = ans.AnswerText,
                    IsCorrect = ans.IsCorrect,
                    QuestionId = ans.QuestionId
                });
            }

            context.SaveChanges();
        }
    }
}
