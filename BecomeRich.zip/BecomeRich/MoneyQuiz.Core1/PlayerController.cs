﻿using Microsoft.EntityFrameworkCore;
using MoneyQuiz.ConsoleApp.Data.Models;
using MoneyQuiz.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Core1
{
    public class PlayerController
    {
        MoneyQuizDbContext context = new MoneyQuizDbContext();
        public void AddPlayer(string name, string email)
        {
            var player = new Player
            {
                Name = name,
                Email = email
            };

            context.Players.Add(player);
            context.SaveChanges();
        }
    }
}
