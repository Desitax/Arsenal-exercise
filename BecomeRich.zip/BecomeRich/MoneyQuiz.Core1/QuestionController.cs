﻿using Microsoft.EntityFrameworkCore;
using MoneyQuiz.ConsoleApp.Data.Models;
using MoneyQuiz.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Core1
{
    public class QuestionController
    {
        MoneyQuizDbContext context = new MoneyQuizDbContext();
        public void AddQuestions(Questions questions)
        {
            context.Questions.Add(questions);
            context.SaveChanges();
        }
        public List<Questions> ReadQuestion()
        {
            return context.Questions.ToList();
        }
        public void UpdateQuestion(int id, string QuestionText, decimal Amount)
        {
            var question = context.Questions.Find(id);
            if (question != null)
            {
                question.QuestionText = QuestionText;
                question.Amount = Amount;
                context.Questions.Update(question);
                context.SaveChanges();
            }
        }
        public void DeleteQuestion(int id)
        {
            var question = context.Questions.Find(id);
            if (question != null)
            {
                context.Questions.Remove(question);
            }
        }
        public List<string> GetQuestionsAboveAmount(decimal amount = 3000)
        {
            return context.Questions
                .Where(q => q.Amount > amount)
                .Select(q => q.QuestionText)
                .ToList();
        }
        public List<Questions> GetQuestionsWithAllAnswers()
        {
            return context.Questions
                .Include(q => q.Answers)
                .ToList();
        }
        public List<Questions> GetQuestionsWithCorrectAnswerByAmount(decimal amount)
        {
            return context.Questions
                .Include(q => q.Answers)
                .Where(q => q.Amount == amount)
                .ToList();
        }
    }
}
