﻿
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace DataBaseProject
{
    internal class Program
    {
        static void Main(string[] args)
        { 
            string connectionString = @"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;";

            ShowMenu();
            string input = Console.ReadLine();
            InsertRequests insertRequests = new InsertRequests();
            SelectRequests selectRequest = new SelectRequests();

            while (input != "End")
            {
                switch (input)
                {
                    case "1":
                        insertRequests.InsertSubjects();
                        
                        break;
                    case "2":
                        insertRequests.InsertStudents();
                        break;
                    case "3":
                        insertRequests.InsertTeachers();
                        break;
                    case "4":
                        insertRequests.InsertStudentsTeachers();
                        break;
                    case "5":
                        insertRequests.InsertAcademy();
                        break;
                    case "6":
                        selectRequest.SelectStudentsByName();
                        break;
                    case "7":
                        selectRequest.SelectSubjectsByName();
                        break;
                    case "8":
                        selectRequest.StudentsOfAge();
                        break;
                    case "9":
                        selectRequest.SelectTeachersBySpecificSubject();
                        break;
                    case "10":
                        selectRequest.SelectTeachersTeachingByYears();
                        break;
                    case "11":
                        selectRequest.SelectStudentsAndTheirSubjects();
                        break;
                    case "12":
                        selectRequest.SelectTeachersByName();
                        break;
                    case "13":
                        selectRequest.SelectSubjectsByPrice();
                        break;
                    case "14":
                        selectRequest.SelectStudentsYearsOfTeaching();
                        break;
                    case "15":
                        selectRequest.SelectSubjectsInfo();
                        break;

                    default:
                        Console.WriteLine("Invalid option. Please select a valid option.");
                        break;
                }
                input = Console.ReadLine();
            }
        }

        private static void DropAndRecreateDatabase(SqlConnection sqlConnection, object value)
        {
            throw new NotImplementedException();
        }

        public static void ShowMenu()
        {
            Console.Clear();
            Console.WriteLine("=== Database Query Menu ===");
            Console.WriteLine("1. Insert in Subjects.");
            Console.WriteLine("2. Insert in Students.");
            Console.WriteLine("3. Insert in Teachers.");
            Console.WriteLine("4. Insert in StudentsTeachres.");
            Console.WriteLine("5. Insert in Academy.");
            Console.WriteLine("6. Select students by name.");
            Console.WriteLine("7. Select subject by name.");
            Console.WriteLine("8. Select students of age.");
            Console.WriteLine("9. Select teachers by specific subject.");
            Console.WriteLine("10. Select teachers teaching by years.");
            Console.WriteLine("11. Select students and their subjects.");
            Console.WriteLine("12. Select teachers by name.");
            Console.WriteLine("13. Select subjects by price.");
            Console.WriteLine("14. Select students years of teaching.");
            Console.WriteLine("15. Select subjects info.");
        }
    }
}
