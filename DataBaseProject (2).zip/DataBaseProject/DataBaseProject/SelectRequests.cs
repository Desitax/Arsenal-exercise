﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseProject
{
    public class SelectRequests
    {
        public void SelectStudentsByName()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();
                Console.WriteLine("Enter name of student: ");
                string name = Console.ReadLine();

                string query = @"SELECT surname, age, city, dateOfBirth  FROM Students WHERE name=@name";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@name", name);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Surname: {reader["surname"]}, age: {reader["age"]}");
                        }
                    }
                }

            }
        }
        public void SelectSubjectsByName()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();
                Console.WriteLine("Enter name of subject: ");
                string name = Console.ReadLine();
                string query = @"SELECT price,duration FROM Subjects WHERE name=@name";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue($"@name", name);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Price: {reader["price"]}, duration: {reader["duration"]}");
                        }
                    }
                }
            }
        }
        public void StudentsOfAge()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();
                string query = @"SELECT name, surname, age FROM Students WHERE age > 18";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Name: {reader[0]}, surname: {reader[1]}, age: {reader[2]}");
                        }
                    }
                }
            }
        }
        public void SelectTeachersBySpecificSubject()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();
                string query = @"SELECT t.name AS teacher_name, t.surname AS teacher_surname, s.name AS subject_name
          FROM Teachers t
          JOIN Subjects s ON t.subject_id = s.subject_id
          WHERE s.subject_id = 1";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Teacher name: {reader[0]}, Teacher surname: {reader[1]},");
                        }
                    }
                }
            }
        }
        public void SelectTeachersTeachingByYears()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;;"))
            {
                connection.Open();
                string query = @" 
         SELECT name, surname, yearsOfTeaching
         FROM Teachers
         WHERE yearsOfTeaching > 5;";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Teacher name: {reader[0]}, teacher surname: {reader[1]}, years of teaching: {reader[2]}");

                        }
                    }
                }
            }
        }
        public void SelectStudentsAndTheirSubjects()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();
                string query = @"SELECT Students.name,Students.surname,Subjects.name
         FROM Students
         JOIN StudentsTeachers ON Students.student_id = StudentsTeachers.student_id
         JOIN Teachers ON StudentsTeachers.teacher_id = Teachers.teacher_id
         JOIN Subjects ON Teachers.subject_id = Subjects.subject_id";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Student name: {reader[0]}, student surname: {reader[1]}, subject name: {reader[2]}");
                        }
                    }
                }
            }
        }
        public void SelectTeachersByName()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();
                Console.WriteLine("Enter teacher name to find it: ");
                string name = Console.ReadLine();
                Console.WriteLine("Enter teacher surname to find it: ");
                string surname = Console.ReadLine();

                string query = @"SELECT name,surname,age,phoneNumber
         FROM Teachers
         WHERE name=@name AND surname=@surname";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@name", surname);
                    command.Parameters.AddWithValue("@surname", surname);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Teacher name: {reader["@name"]}, teacher surname: {reader["@surname"]}, age: {reader[2]}, phoneNumber: {reader[3]}");
                        }
                    }
                }
            }
        }
        public void SelectSubjectsByPrice()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();
                Console.WriteLine("Enter price: ");
                string price = Console.ReadLine();
                string query = @"
         SELECT name, price
         FROM Subjects
         WHERE price > @price";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@price", price);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Subject name: {reader[0]}, subject price: {reader[1]}");
                        }
                    }
                }
            }
        }
        public void SelectStudentsYearsOfTeaching()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();
                string query = @"SELECT Students.name, Students.surname, StudentsTeachers.yearsOfCollaborationWork 
         FROM Students
         JOIN StudentsTeachers ON Students.student_id = StudentsTeachers.student_id";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Student name: {reader[0]}, student surname: {reader[1]}, years of teaching: {reader[2]}");
                        }
                    }
                }
            }
        }
        public void SelectSubjectsInfo()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();
                string query = @"SELECT name,price,duration FROM Subjects";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine($"Suject name: {reader[0]}, subject price: {reader[1]}, subject duration: {reader[2]}");
                        }
                    }
                }
            }
        }
    }
}
