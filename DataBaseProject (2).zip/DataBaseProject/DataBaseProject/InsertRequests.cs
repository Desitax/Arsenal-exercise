﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseProject
{
    public class InsertRequests
    {
        public void InsertSubjects()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();

                Console.WriteLine("Enter subject name: ");
                string subjectName = Console.ReadLine();

                Console.WriteLine("Enter subject price: ");
                double price = double.Parse(Console.ReadLine());

                Console.WriteLine("Enter subject duration: ");
                int duration = int.Parse(Console.ReadLine());

                string insertSubjects = @"INSERT INTO Subjects(name, price, duration)
                VALUES (@subjectName, @price, @duration)";
                using (SqlCommand cmd = new SqlCommand(insertSubjects, connection))
                {
                    cmd.Parameters.AddWithValue("@subjectName", subjectName);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@duration", duration);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public void InsertStudents()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();

                Console.WriteLine("Enter student name: ");
                string studentName = Console.ReadLine();

                Console.WriteLine("Enter student surname: ");
                string studentSurname = Console.ReadLine();

                Console.WriteLine("Enter student age: ");
                int studentAge = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter student city: ");
                string stuentCity = Console.ReadLine();

                Console.WriteLine("Enter student date of birth: ");
                DateTime studentDateOfBirth = DateTime.Parse(Console.ReadLine());

                string insertStudents = @"INSERT INTO Students(name,surname,age,city,dateOfBirth)
                VALUES(@name,@surname,@age,@city,@dateOfBirth)";

                using (SqlCommand command = new SqlCommand(insertStudents, connection))
                {
                    command.Parameters.AddWithValue("@name", studentName);
                    command.Parameters.AddWithValue("@surname", studentSurname);
                    command.Parameters.AddWithValue("@age", studentAge);
                    command.Parameters.AddWithValue("@city", stuentCity);
                    command.Parameters.AddWithValue("@dateOfBirth", studentDateOfBirth);
                    command.ExecuteNonQuery();
                }
            }
        }
        public void InsertTeachers()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();

                Console.WriteLine("Enter subject ID: ");
                int subjectId = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter teacher name: ");
                string teacherName = Console.ReadLine();

                Console.WriteLine("Enter teacher surname: ");
                string teacherSurname = Console.ReadLine();

                Console.WriteLine("Enter teacher age: ");
                int teacherAge = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter teacher city: ");
                string teacherCity = Console.ReadLine();

                Console.WriteLine("Enter teacher phone number: ");
                string teacherPhoneNumber = Console.ReadLine();

                Console.WriteLine("Enter teacher date of birth (yyyy-MM-dd): ");
                DateTime teacherDateOfBirth = DateTime.Parse(Console.ReadLine());

                Console.WriteLine("Enter teacher years of teaching: ");
                int teacherYearsOfTeaching = int.Parse(Console.ReadLine());

                string insertTeachers = @" 
                INSERT INTO Teachers(subject_id,name,surname,age,city,phoneNumber,dateOfBirth,yearsOfTeaching)
                VALUES(@subject_id,@name,@surname,@age,@city,@phoneNumber,@dateOfBirth,@yearsOfTeaching)";

                using (SqlCommand command = new SqlCommand(insertTeachers, connection))
                {
                    command.Parameters.AddWithValue("@subject_id", subjectId);
                    command.Parameters.AddWithValue("@name", teacherName);
                    command.Parameters.AddWithValue("@surname", teacherSurname);
                    command.Parameters.AddWithValue("@age", teacherAge);
                    command.Parameters.AddWithValue("@city", teacherCity);
                    command.Parameters.AddWithValue("@phoneNumber", teacherPhoneNumber);
                    command.Parameters.AddWithValue("@dateOfBirth", teacherDateOfBirth);
                    command.Parameters.AddWithValue("@yearsOfTeaching", teacherYearsOfTeaching);
                    command.ExecuteNonQuery();
                }
            }
        }
        public void InsertStudentsTeachers()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;;"))
            {
                connection.Open();

                Console.WriteLine("Enter student ID: ");
                int studentId = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter teacher ID: ");
                int teacherId = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter years of collaboration working:");
                int yearsOfCollaborationWorking = int.Parse(Console.ReadLine());

                string insertPeople = @"INSERT INTO StudentsTeachers(student_id, teacher_id, yearsOfCollaborationWork)
                                VALUES(@student_id, @teacher_id, @yearsOfCollaborationWork)";

                using (SqlCommand command = new SqlCommand(insertPeople, connection))
                {
                    command.Parameters.AddWithValue("@student_id", studentId); 
                    command.Parameters.AddWithValue("@teacher_id", teacherId);
                    command.Parameters.AddWithValue("@yearsOfCollaborationWork", yearsOfCollaborationWorking); 
                    command.ExecuteNonQuery();
                }
            }
        }
        public void InsertAcademy()
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=STUDENT16;Integrated Security=True;Initial Catalog=DateBaseProject;"))
            {
                connection.Open();

                Console.WriteLine("Enter name of academy: ");
                string academyName = Console.ReadLine();

                Console.WriteLine("Enter student ID: ");
                int studentId = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter teacher ID: ");
                int teacherId = int.Parse(Console.ReadLine());

                string insertAcademy = @"INSERT INTO Academy(name,student_id,teacher_id)
                VALUES(@name,@studentId,@teacherId)";

                using (SqlCommand command = new SqlCommand(insertAcademy, connection))
                {
                    command.Parameters.AddWithValue("@name", academyName);
                    command.Parameters.AddWithValue("@studentId", studentId);
                    command.Parameters.AddWithValue("@teacherId", teacherId);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
